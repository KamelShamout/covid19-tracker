package com.Covid19Tracker.Covid19Tracker.Controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.Covid19Tracker.Covid19Tracker.Entities.Cases;
import com.Covid19Tracker.Covid19Tracker.Entities.City;
import com.Covid19Tracker.Covid19Tracker.Services.CitiesService;
import com.fasterxml.jackson.databind.ObjectMapper;
@RunWith(SpringRunner.class)
@WebMvcTest(value=CitiesController.class)
@AutoConfigureMockMvc
class CitiesControllerTest {
@Autowired
MockMvc mvc;
@MockBean
CitiesService service;
@Autowired
private ObjectMapper objectMapper;
List<City> Cases() {
	City city = new City();
	Cases case1 = new Cases();
	case1.setDate("2020-11-04 00:00:00.0");
	case1.setId(0);
	case1.setCountry(city);
	case1.setNumberofcases(100);
	Cases case2 = new Cases();
	case2.setDate("2020-12-04 00:00:00.0");
	case2.setId(1);
	case2.setCountry(city);

	case2.setNumberofcases(200);
	Cases case3 = new Cases();
	case3.setCountry(city);

	case3.setDate("2020-10-04 00:00:00.0");
	case3.setId(2);
	case3.setNumberofcases(300);
	city.setName("Amman");
	city.setId("Amman");
	List<Cases> cases = new ArrayList<Cases>();
	cases.add(case1);
	cases.add(case2);
	cases.add(case3);
	city.setCases(cases);
	List<City> cities =new ArrayList<City>();
	cities.add(city);
	return cities;
}

	@Test
	void getallcases() throws Exception {
		String temp="[{\"name\":\"Amman\",\"id\":\"Amman\",\"cases\":"
				+ "[{\"date\":\"2020-11-04 00:00:00.0\",\"numberofcases\""
				+ ":100,\"id\":0},{\"date\":\"2020-12-04 00:00:00.0\","
				+ "\"numberofcases\":200,\"id\":1},{\"date\":\"2020-10-04 00:00:00.0\""
				+ ",\"numberofcases\":300,\"id\":2}]}]";
when(service.GetAllCases()).thenReturn(Cases());
mvc.perform(get("/cities/allcases")).andDo(print())
.andExpect(status().isOk())
.andExpect(content().string(temp));
	
	}
	@Test
	void LastCitiesUpdate() throws Exception {
		Hashtable <String,Cases> data=new Hashtable<>();
		data.put("Amman",Cases().get(0).getCases().get(1));
		String temp="{\"Amman\":{\"date\":\"2020-12-04 00:00:00.0\",\"numberofcases\":200,\"id\":1}}";
	when(service.LastCitiesUpdate()).thenReturn(data);
		mvc.perform(get("/cities/lastupdateall")).andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string(temp));
		
	}
	@Test
	void LastCityUpdate() throws Exception {
		Hashtable <String,Cases> data=new Hashtable<>();
		data.put("Amman",Cases().get(0).getCases().get(1));
		String temp="{\"Amman\":{\"date\":\"2020-12-04 00:00:00.0\",\"numberofcases\":200,\"id\":1}}";
		when(service.LastCityUpdate(objectMapper.writeValueAsString("Amman"))).thenReturn(data);
		mvc.perform(post("/cities/lastupdate")
				.content(objectMapper.writeValueAsString("Amman"))
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string(temp));
		
	}
	
	@Test
	void GetByDate() throws Exception {
		Hashtable <String,Integer> data=new Hashtable<>();
		data.put("Amman",200);
		when(service.GetByDate(objectMapper.writeValueAsString("2020-12-04 00:00:00.0"))).thenReturn(data);
		mvc.perform(get("/cities/citiesbydate/").
				content(objectMapper.writeValueAsString("2020-12-04 00:00:00.0")).contentType(MediaType.APPLICATION_JSON))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string("{\"Amman\":200}"));
		
		
	}
	@Test
	void GetByCity() throws Exception {
		String temp="{\"name\":\"Amman\",\"id\":\"Amman\",\"cases\":"
				+ "[{\"date\":\"2020-11-04 00:00:00.0\",\"numberofcases\":100,\"id\":0},"
				+ "{\"date\":\"2020-12-04 00:00:00.0\",\"numberofcases\":200,\"id\":1},"
				+ "{\"date\":\"2020-10-04 00:00:00.0\",\"numberofcases\":300,\"id\":2}]}";
		when(service.GetByCity(objectMapper.writeValueAsString("Amman"))).thenReturn(Cases().get(0));
		mvc.perform(post("/cities/casesbycity").
				content(objectMapper.writeValueAsString("Amman")).contentType(MediaType.APPLICATION_JSON))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string(temp));
		
		
	}

}
