package com.Covid19Tracker.Covid19Tracker.Controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.Covid19Tracker.Covid19Tracker.Entities.User;
import com.Covid19Tracker.Covid19Tracker.Services.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
@RunWith(SpringRunner.class)
@WebMvcTest(value=UserController.class)
@AutoConfigureMockMvc()
class UserControllerTest {
	@Autowired
	MockMvc mvc;
	@MockBean
	UserService service;
	@Autowired
	private ObjectMapper objectMapper;

	List<User> GetUsers() {
		User user = new User();
		user.setCity("Irbid");
		user.setEmail("belalkamel113@gmail.com");
		user.setId(0);
		user.setIsadmin(true);
		user.setName("moayed tayem");
		user.setPassword("741258");
		User user1 = new User();
		user1.setCity("Amman");
		user1.setEmail("kamelbelal@yahoo.com");
		user1.setId(1);
		user1.setIsadmin(false);
		user1.setName("eyad qasem");
		user1.setPassword("456789");
		List<User> users = new ArrayList<User>();
		users.add(user);
		users.add(user1);
		return users;
	}
	
	@Test
	void  findbyEmail() throws Exception {
		String temp="{\"id\":1,\"email\":\"kamelbelal@yahoo.com\","
				+ "\"city\":\"Amman\",\"isadmin\":false,"
				+ "\"password\":\"456789\",\"name\":\"eyad qasem\"}";
		when(service.findbyEmail(objectMapper.writeValueAsString("kamelbelal@yahoo.com"))).thenReturn(GetUsers().get(1));
		mvc.perform(post("/user/userbyemail")
				.content(objectMapper.writeValueAsString("kamelbelal@yahoo.com"))
				.contentType(MediaType.APPLICATION_JSON)).andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string(temp));
	}
}
