package com.Covid19Tracker.Covid19Tracker.Controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;
import com.Covid19Tracker.Covid19Tracker.Services.JordanService;
@RunWith(SpringRunner.class)
@WebMvcTest(value=JordanController.class)
@AutoConfigureMockMvc
class JordanControllerTest {

@Autowired
MockMvc mvc;
@MockBean
JordanService service;
@Autowired

List<TotalCases> Cases() {
	TotalCases case1 = new TotalCases();
	case1.setDate("2020-12-04 00:00:00.0");
	case1.setCasesoftoday(500);
	case1.setDeathsoftoday(40);
	case1.setConductedtestsoftoday(70);
	case1.setId(0);
	case1.setTotalrecoveries(300);
	case1.setRecoveriesoftoday(30);
	case1.setTotalcases(7000);
	case1.setTotalconductedtests(200);
	case1.setTotaldeaths(50);
	TotalCases case2 = new TotalCases();
	case2.setDate("2020-11-04 00:00:00.0");
	case2.setCasesoftoday(1000);
	case2.setDeathsoftoday(90);
	case2.setConductedtestsoftoday(50);
	case2.setId(1);
	case2.setTotalrecoveries(3000);
	case2.setRecoveriesoftoday(2);
	case2.setTotalcases(8000);
	case2.setTotalconductedtests(450);
	case2.setTotaldeaths(88);
	List<TotalCases> cases=new ArrayList<TotalCases>();
	cases.add(case1);
	cases.add(case2);
	
	return cases;
	
}
	@Test
	void LastUpdateForJor() throws Exception {
String temp="{\"casesoftoday\":500,\"totalcases\":7000,\"deathsoftoday\""
		+ ":40,\"totaldeaths\":50,\"conductedtestsoftoday\":70,\"totalconductedtests\":200,\"recoveriesoftoday\":30,"
		+ "\"totalrecoveries\":300,\"date\":\"2020-12-04 00:00:00.0\",\"id\":0}";
		when(service.LastUpdate()).thenReturn(Cases().get(0));
		mvc.perform(get("/jordancases/lastupdate")).andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string(temp));
	}
	
	@Test
	void AllCases() throws Exception {
		String temp="[{\"casesoftoday\":500,\"totalcases\":7000,\"deathsoftoday\":"
				+ "40,\"totaldeaths\":50,\"conductedtestsoftoday\":70,\"totalconductedtests\":"
				+ "200,\"recoveriesoftoday\":30,\"totalrecoveries\":300,\"date\":\"2020-12-04 00:00:00.0\""
				+ ",\"id\":0},{\"casesoftoday\":1000,\"totalcases\":8000,\"deathsoftoday\":90,\"totaldeaths\":"
				+ "88,\"conductedtestsoftoday\":50,\"totalconductedtests\":450,\"recoveriesoftoday\""
				+ ":2,\"totalrecoveries\":3000,\"date\":\"2020-11-04 00:00:00.0\",\"id\":1}]";
		when(service.GetCases()).thenReturn(Cases());
		mvc.perform(get("/jordancases/cases")).andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().string(temp));
	}

}
