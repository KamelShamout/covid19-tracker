package com.Covid19Tracker.Covid19Tracker.DataBaseTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.Covid19Tracker.Covid19Tracker.Entities.Cases;
import com.Covid19Tracker.Covid19Tracker.Entities.City;
import com.Covid19Tracker.Covid19Tracker.Repositores.CasesRepository;
import com.Covid19Tracker.Covid19Tracker.Repositores.CityRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class CasesRepositoryTest {
	@Autowired
	private TestEntityManager entityManager;
	@Autowired
	private CasesRepository casesrp;
	@Autowired
	private CityRepository cityrp;

	@Test
	void SaveCases() {
		City city = new City();
		Cases case1 = new Cases();
		case1.setDate("2020-11-04 00:00:00.0");
		case1.setId(0);
		case1.setCountry(city);
		case1.setNumberofcases(100);
		Cases case2 = new Cases();
		case2.setDate("2020-12-04 00:00:00.0");
		case2.setId(1);
		case2.setCountry(city);

		case2.setNumberofcases(200);
		Cases case3 = new Cases();
		case3.setCountry(city);

		case3.setDate("2020-10-04 00:00:00.0");
		case3.setId(2);
		case3.setNumberofcases(300);
		city.setName("Amman");
		city.setId("Amman");
		List<Cases> cases = new ArrayList<Cases>();
		cases.add(case1);
		cases.add(case2);
		cases.add(case3);
		entityManager.persist(city);
		City findindb = cityrp.findById("Amman").get();
		assertThat(findindb).isEqualTo(city);
	}

	@Test
	void FindByDate() {
		List<Cases> cases = casesrp.findByDate("2020-11-04 00:00:00.0");
		for (Cases cases2 : cases) {
			assertEquals("Amman", cases2.getCountry().getId());
		}

	}

	@Test
	void FindLastUpdate() {
		List<Cases> cases = casesrp.findtheLastUpdate();
		for (Cases cases2 : cases) {
			assertEquals("2020-12-04 00:00:00.0", cases2.getDate());
		}
	}

}
