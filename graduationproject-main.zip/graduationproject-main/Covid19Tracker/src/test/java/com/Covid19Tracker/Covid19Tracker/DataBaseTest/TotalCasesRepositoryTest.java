package com.Covid19Tracker.Covid19Tracker.DataBaseTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;
import com.Covid19Tracker.Covid19Tracker.Repositores.TotalCasesRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class TotalCasesRepositoryTest {

	@Autowired
	private TestEntityManager entityManager;
	@Autowired
	private TotalCasesRepository totalcasesrp;

	@Test
	void SaveCases() {
		TotalCases case1 = new TotalCases();
		case1.setDate("2020-12-04 00:00:00.0");
		case1.setCasesoftoday(500);
		case1.setDeathsoftoday(40);
		case1.setConductedtestsoftoday(70);
		case1.setId(0);
		case1.setTotalrecoveries(300);
		case1.setRecoveriesoftoday(30);
		case1.setTotalcases(7000);
		case1.setTotalconductedtests(200);
		case1.setTotaldeaths(50);
		TotalCases case2 = new TotalCases();
		case2.setDate("2020-11-04 00:00:00.0");
		case2.setCasesoftoday(1000);
		case2.setDeathsoftoday(90);
		case2.setConductedtestsoftoday(50);
		case2.setId(1);
		case2.setTotalrecoveries(3000);
		case2.setRecoveriesoftoday(2);
		case2.setTotalcases(8000);
		case2.setTotalconductedtests(450);
		case2.setTotaldeaths(88);
		entityManager.persist(case1);
		entityManager.persist(case2);
		TotalCases findindb = totalcasesrp.findByDate("2020-12-04 00:00:00.0");
		assertThat(findindb).isEqualTo(case1);
	}

	@Test
	void FindLastUpdate() {
		TotalCases cases = totalcasesrp.findtheLastUpdate();
		assertEquals("2020-12-04 00:00:00.0", cases.getDate());

	}

	@Test
	void findAllOrderByDateAsc() {
		List<TotalCases> cases = totalcasesrp.findAllOrderByDateAsc();

		assertEquals("2020-11-04 00:00:00.0", cases.get(0).getDate());
		assertEquals("2020-12-04 00:00:00.0", cases.get(1).getDate());

	}
}
