package com.Covid19Tracker.Covid19Tracker.DataBaseTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.Covid19Tracker.Covid19Tracker.Entities.User;
import com.Covid19Tracker.Covid19Tracker.Repositores.UserRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class UserRepositoryTest {
	@Autowired
	private TestEntityManager entityManager;
	@Autowired
	private UserRepository userrp;

	User GetUser() {
		User user = new User();
		user.setCity("zarqa");
		user.setEmail("belalkamel962@gmail.com");
		user.setId(3);
		user.setIsadmin(true);
		user.setName("kamel belal");
		user.setPassword("123456");
		return user;
	}

	List<User> GetUsers() {
		User user = new User();
		user.setCity("Irbid");
		user.setEmail("belalkamel113@gmail.com");
		user.setId(0);
		user.setIsadmin(true);
		user.setName("moayed tayem");
		user.setPassword("741258");
		User user1 = new User();
		user1.setCity("Amman");
		user1.setEmail("kamelbelal@yahoo.com");
		user1.setId(1);
		user1.setIsadmin(false);
		user1.setName("eyad qasem");
		user1.setPassword("456789");
		List<User> users = new ArrayList<User>();
		users.add(user);
		users.add(user1);
		return users;
	}

	@Test

	void TestSaveUser() {
		User user = GetUser();
		User saveindb = entityManager.persist(user);
		User findindb = userrp.findByEmail(user.getEmail());
		assertThat(findindb).isEqualTo(saveindb);

	}

	@SuppressWarnings("deprecation")
	@Test
	void TestReturnAllEmails() {
		List<User> users = GetUsers();
		String[] temp = new String[2];

		for (User user : users) {

			entityManager.persistAndFlush(user);
			temp[(int) user.getId()] = user.getEmail();
		}

		String[] Emails = userrp.findAllEmails();
		assertEquals(temp, Emails);

	}

	@SuppressWarnings("deprecation")
	@Test
	void TestReturnAdminsEmails() {
		String[] temp = { "belalkamel113@gmail.com", "belalkamel962@gmail.com" };

		String[] Emails = userrp.findAdminsEmails();
		assertEquals(temp, Emails);

	}

	@Test
	void TestReturnAdmins() {
		List<User> users = GetUsers();
		users.add(GetUser());
		List<User> temp = new ArrayList<User>();
		temp.add(users.get(0));
		temp.add(users.get(2));
		List<User> Admins = userrp.findByType(true);

		for (int i = 0; i < Admins.size(); i++) {
			assertEquals(temp.get(i).getEmail(), Admins.get(i).getEmail());
			assertEquals(temp.get(i).getCity(), Admins.get(i).getCity());
			assertEquals(temp.get(i).getName(), Admins.get(i).getName());
		}

	}

}
