package com.Covid19Tracker.Covid19Tracker.DataCollectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.springframework.beans.factory.annotation.Autowired;

class DataCollectorTest {
	
	@Autowired
	DataCollector collector;
	
	@org.junit.Before
	public void ChromeDriverpath() {
		System.setProperty("webdriver.firefox.driver", "/Covid19Tracker/geckodriver.exe");

	}
	@Test
	void WebElement() {
		FirefoxOptions options = new FirefoxOptions();
		WebDriver driver=new FirefoxDriver(options);
		options.setHeadless(true);
driver.get("https://corona.moh.gov.jo/en/MediaCenter/4799");
collector=new DataCollector();
WebElement element= collector.GetElement(driver);
String temp="distributed";
assertEquals(temp.contains("distributed"), element.getText().contains("distributed"));	
driver.close();

	}
	@Test
	void WebElementexception() {
		FirefoxOptions options = new FirefoxOptions();
		options.setHeadless(true);
		WebDriver driver=new FirefoxDriver(options);
		driver.get("https://corona.moh.gov.jo/en/MediaCenter/2587");
		collector=new DataCollector();
		WebElement element= collector.GetElement(driver);
		String temp="distributed";
		assertEquals(temp.contains("distributed"), element.getText().contains("distributed"));
		driver.close();
		
	}

}
