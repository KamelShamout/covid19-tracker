package com.Covid19Tracker.Covid19Tracker.Controller;

import java.util.Hashtable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Covid19Tracker.Covid19Tracker.Entities.Cases;
import com.Covid19Tracker.Covid19Tracker.Entities.City;
import com.Covid19Tracker.Covid19Tracker.Services.AddCase;

@RestController
public class CitiesController {

	@Autowired
	public com.Covid19Tracker.Covid19Tracker.Services.CitiesService citiesservice;

	@PostMapping(value = "/cities/insertdata")
	public boolean InsertByCountry(@RequestBody List<AddCase> addCase) {
		return citiesservice.InsertByCountry(addCase);
	}

	@GetMapping(value = "/cities/allcases")
	public List<City> GetAllCases() {
		return citiesservice.GetAllCases();
	}

	@GetMapping(value = "/cities/citiesbydate")
	public Hashtable<String, Integer> GetByDate(@RequestParam String date) {
		return citiesservice.GetByDate(date);
	}

	@PostMapping(value = "/cities/casesbycity")
	public Object GetByCity(@RequestBody String country) {
		return citiesservice.GetByCity(country);
	}

	@PostMapping(value = "/cities/lastupdate")
	public Hashtable<String, Cases> LastCityUpdate(@RequestBody String city) {
		return citiesservice.LastCityUpdate(city);
	}

	@GetMapping(value = "/cities/lastupdateall")
	public Hashtable<String, Cases> LastCitiesUpdate() {

		return citiesservice.LastCitiesUpdate();
	}

}
