package com.Covid19Tracker.Covid19Tracker.Repositores;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;

public interface TotalCasesRepository extends JpaRepository<TotalCases, Long> {

	@Query(value = "FROM TotalCases WHERE date= (SELECT max(date) FROM TotalCases )")
	TotalCases findtheLastUpdate();

	@Query("FROM TotalCases WHERE date=?1")
	TotalCases findByDate(String date);

	@Query(value = "SELECT max(id) FROM TotalCases")
	long findtheLastId();

	@Query("FROM TotalCases ORDER BY date ASC")
	List<TotalCases> findAllOrderByDateAsc();

}
