package com.Covid19Tracker.Covid19Tracker.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;
import com.Covid19Tracker.Covid19Tracker.Repositores.TotalCasesRepository;

@Service
public class JordanService {
	@Autowired
	TotalCasesRepository totalcasesrepository;

	public TotalCases LastUpdate() {

		return totalcasesrepository.findtheLastUpdate();

	}

	public Object GetCases() {

		try {
			return totalcasesrepository.findAllOrderByDateAsc();
		} catch (Exception ex) {
			return null;
		}
	}

	public boolean CreateCase(TotalCases cases) {
		cases.setId(totalcasesrepository.findAll().isEmpty() ? 0 : totalcasesrepository.findtheLastId() + 1);
		totalcasesrepository.saveAndFlush(cases);
		return true;
	}
}
