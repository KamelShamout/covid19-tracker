package com.Covid19Tracker.Covid19Tracker.Services;

import java.util.Hashtable;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Covid19Tracker.Covid19Tracker.Entities.Cases;
import com.Covid19Tracker.Covid19Tracker.Entities.City;
import com.Covid19Tracker.Covid19Tracker.Repositores.CasesRepository;
import com.Covid19Tracker.Covid19Tracker.Repositores.CityRepository;

@Service
public class CitiesService {
	@Autowired
	public CasesRepository casesRepository;
	@Autowired
	public CityRepository countryRepository;

	public boolean InsertByCountry(List<AddCase> addCase) {
		for (AddCase addCase2 : addCase) {
			if (!countryRepository.existsById(addCase2.getCity()))
				return false;
			InsertDataByCity(addCase2.getCity(), CreateCase(addCase2.getDate(), addCase2.getCases(), addCase2.getCity()));

		}
		return true;
	}

	public List<City> GetAllCases() {
		List<City> cities = countryRepository.findAll();
		for (int i = 0; i < cities.size(); i++)
			cities.get(i).setCases(casesRepository.findCityOrderByDateAsc(cities.get(i).getId()));
		return cities;
	}

	public Hashtable<String, Integer> GetByDate(String date) {
		List<Cases> temp = casesRepository.findByDate(date.toString());
		Hashtable<String, Integer> data = new Hashtable<String, Integer>();
		for (Cases cases : temp) {
			data.put(cases.getCountry().getId(), cases.getNumberofcases());
		}

		return data;
	}

	public City GetByCity(String country) {
		Optional<City> city = countryRepository.findById(country.toString().trim());
		city.get().setCases(casesRepository.findCityOrderByDateAsc(city.get().getName()));
		return city.get();
	}

	public Hashtable<String, Cases> LastCityUpdate(String city) {

		Hashtable<String, Cases> data = new Hashtable<String, Cases>();
		Optional<City> temp = countryRepository.findById(city.trim().toString());
		City temp2 = temp.get();
		temp2.setCases(casesRepository.findCityOrderByDateAsc(city));
		data.put(temp2.getId(), temp2.getCases().get(temp2.getCases().size() - 1));
		return data;
	}

	public Hashtable<String, Cases> LastCitiesUpdate() {

		Hashtable<String, Cases> data = new Hashtable<String, Cases>();

		List<Cases> cases = casesRepository.findtheLastUpdate();
		for (Cases casee : cases) {
			data.put(casee.getCountry().getName(), casee);

		}
if(cases.size()<12)
	return null;
		return data;
	}

	public void InsertDataByCity(String city, Cases cases) {
		Optional<City> temp = countryRepository.findById(city);

		temp.get().SetCase(cases);
		countryRepository.saveAndFlush(temp.get());

	}

	public Cases CreateCase(String date, int number, String city) {
		Optional<City> temp = countryRepository.findById(city);

		return new Cases(casesRepository.findAll().isEmpty() ? 0 : casesRepository.findtheLastId() + 1, date, number,
				temp.get());
	}

	public List<Cases> LastCitiesUpdateForEmail() {

		return casesRepository.findtheLastUpdate();
	}

	public String LastDateForEmail() {

		return casesRepository.findtheLastDate();
	}

}
