package com.Covid19Tracker.Covid19Tracker.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Covid19Tracker.Covid19Tracker.Entities.User;
import com.Covid19Tracker.Covid19Tracker.Services.Login;
import com.Covid19Tracker.Covid19Tracker.Services.UserService;

@RestController
public class UserController {
	@Autowired
	public UserService userservice;

	@PostMapping(value = "/user/userbyemail")
	public User findbyEmail(@RequestBody String email) {
		return userservice.findbyEmail(email);
	}

	@PostMapping(value = "/user/signup")
	public boolean Signup(@RequestBody User user) {
		return userservice.Signup(user);

	}

	@PostMapping(value = "/user/login")
	public int Login(@RequestBody Login login) {
		return userservice.Login(login);
	}

	@PostMapping(value = "/user/updateinfo")
	public boolean UpdateInfo(@RequestBody User user) {
		return userservice.UpdateInfo(user);
	}
}
