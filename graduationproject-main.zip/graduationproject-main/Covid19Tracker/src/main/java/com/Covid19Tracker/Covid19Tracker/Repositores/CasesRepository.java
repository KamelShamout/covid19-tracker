package com.Covid19Tracker.Covid19Tracker.Repositores;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.Covid19Tracker.Covid19Tracker.Entities.Cases;

public interface CasesRepository extends JpaRepository<Cases, Long> {
	@Query("FROM Cases WHERE date=?1 ORDER BY date ASC")
	List<Cases> findByDate(String date);

	@Query(value = "FROM Cases WHERE date= (SELECT max(date) FROM Cases )")
	List<Cases> findtheLastUpdate();

	@Query(value = "SELECT max(id) FROM Cases")
	long findtheLastId();

	@Query(value = "SELECT max(date) FROM Cases")
	String findtheLastDate();

	@Query("FROM Cases WHERE city_id=?1 ORDER BY date ASC")
	List<Cases> findCityOrderByDateAsc(String city);

	@Query("FROM Cases WHERE city_id=?1 AND date= (SELECT max(date) FROM Cases )")
	Cases findLastCityUpdate(String city);

	@Query("FROM Cases ORDER BY date ASC")
	List<Cases> findAllCases();
}