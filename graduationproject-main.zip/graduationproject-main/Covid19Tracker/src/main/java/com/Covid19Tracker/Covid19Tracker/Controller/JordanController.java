package com.Covid19Tracker.Covid19Tracker.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;
import com.Covid19Tracker.Covid19Tracker.Services.JordanService;

@RestController
public class JordanController {

	@Autowired
	JordanService jordanservice;

	@GetMapping(value = "/jordancases/lastupdate")
	public Object LastUpdateForJor() {
		return jordanservice.LastUpdate();
	}

	@GetMapping(value = "/jordancases/cases")
	public Object GetJordan() {

		try {
			return jordanservice.GetCases();
		} catch (Exception ex) {
			return null;
		}
	}

	@PostMapping(value = "/jordancases/insertcase")
	public boolean InsertByCountry(@RequestBody TotalCases addCase) {
		return jordanservice.CreateCase(addCase);

	}

}
