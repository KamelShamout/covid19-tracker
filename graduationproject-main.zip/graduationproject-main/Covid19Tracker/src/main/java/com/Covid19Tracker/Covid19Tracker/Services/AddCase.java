package com.Covid19Tracker.Covid19Tracker.Services;

import org.springframework.stereotype.Service;

@Service
public class AddCase {
	private int cases;
	private String date;
	private String city;

	public AddCase() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddCase(int cases, String date, String city) {
		super();
		this.cases = cases;
		this.date = date;
		this.city = city;
	}

	public int getCases() {
		return cases;
	}

	public void setCases(int cases) {
		this.cases = cases;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}
