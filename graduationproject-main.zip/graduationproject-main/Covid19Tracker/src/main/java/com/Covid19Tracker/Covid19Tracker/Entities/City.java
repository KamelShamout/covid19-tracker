package com.Covid19Tracker.Covid19Tracker.Entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Cities")
public class City {
	private String name;

	@Id
	@Column(name = "city_id", length = 64)
	private String id;
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "country", cascade = CascadeType.ALL, orphanRemoval = true)

	private List<Cases> cases = new ArrayList<Cases>();

	public void SetCase(Cases casee) {

		cases.add(casee);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<Cases> getCases() {
		return cases;
	}

	public void setCases(List<Cases> cases) {
		this.cases = cases;
	}

	public City(String name, String id) {
		super();
		this.name = name;
		this.id = id;
	}

	public City() {
		super();
	}

	@Override
	public String toString() {
		return "Country [name=" + name + ", id=" + id + ", cases=" + cases + "]";
	}

}