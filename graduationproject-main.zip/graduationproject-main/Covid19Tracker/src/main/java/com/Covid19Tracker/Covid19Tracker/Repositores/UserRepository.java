package com.Covid19Tracker.Covid19Tracker.Repositores;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.Covid19Tracker.Covid19Tracker.Entities.User;

public interface UserRepository extends JpaRepository<User, Long> {
	@Query("FROM User WHERE email=?1")
	User findByEmail(String email);

	@Query("SELECT email FROM User ")
	String[] findAllEmails();

	@Query("SELECT email FROM User WHERE isadmin=true ")
	String[] findAdminsEmails();

	@Query("FROM User WHERE isadmin=?1")
	List<User> findByType(boolean asadmin);

	@Query(value = "SELECT max(id) FROM User")
	long findtheLastId();
}
