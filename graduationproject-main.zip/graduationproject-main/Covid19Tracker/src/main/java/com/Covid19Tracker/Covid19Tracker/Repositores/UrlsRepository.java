package com.Covid19Tracker.Covid19Tracker.Repositores;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.Covid19Tracker.Covid19Tracker.DataCollectors.Urls;

public interface UrlsRepository extends CrudRepository<Urls, Long> {
	@Query("FROM Urls ORDER BY id ASC")
	List<Urls> findAllOrderByIdAsc();

}
