package com.Covid19Tracker.Covid19Tracker.Entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Cases")
public class Cases {

	private String date;
	private int numberofcases;
	@Id
	private long id;
	@ManyToOne(cascade = CascadeType.ALL, optional = false)
	@JoinColumn(name = "city_id")
	@JsonIgnore
	private City country;

	public Cases(long id, String date, int numberofcases, City country) {
		super();
		this.id = id;
		this.date = date;
		this.numberofcases = numberofcases;
		this.country = country;
	}

	public Cases() {
		super();

	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getNumberofcases() {
		return numberofcases;
	}

	public void setNumberofcases(int numberofcases) {
		this.numberofcases = numberofcases;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public City getCountry() {
		return country;
	}

	public void setCountry(City country) {
		this.country = country;
	}

}
