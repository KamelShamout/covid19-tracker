package com.Covid19Tracker.Covid19Tracker.Entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Jordan_Case")
public class TotalCases {
	private int casesoftoday;
	private int totalcases;
	private int deathsoftoday;
	private int totaldeaths;
	private int conductedtestsoftoday;
	private int totalconductedtests;
	private int recoveriesoftoday;
	private int totalrecoveries;
	private String date;
	@Id
	private long id;

	public TotalCases() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TotalCases(int casesoftoday, int totalcases, int deathsoftoday, int totaldeaths, int conductedtestsoftoday,
			int totalconductedtests, int recoveriesoftoday, int totalrecoveries, String date, long id) {
		super();
		this.casesoftoday = casesoftoday;
		this.totalcases = totalcases;
		this.deathsoftoday = deathsoftoday;
		this.totaldeaths = totaldeaths;
		this.conductedtestsoftoday = conductedtestsoftoday;
		this.totalconductedtests = totalconductedtests;
		this.recoveriesoftoday = recoveriesoftoday;
		this.totalrecoveries = totalrecoveries;
		this.date = date;
		this.id = id;

	}

	public int getCasesoftoday() {
		return casesoftoday;
	}

	public void setCasesoftoday(int casesoftoday) {
		this.casesoftoday = casesoftoday;
	}

	public int getTotalcases() {
		return totalcases;
	}

	public void setTotalcases(int totalcases) {
		this.totalcases = totalcases;
	}

	public int getDeathsoftoday() {
		return deathsoftoday;
	}

	public void setDeathsoftoday(int deathsoftoday) {
		this.deathsoftoday = deathsoftoday;
	}

	public int getTotaldeaths() {
		return totaldeaths;
	}

	public void setTotaldeaths(int totaldeaths) {
		this.totaldeaths = totaldeaths;
	}

	public int getConductedtestsoftoday() {
		return conductedtestsoftoday;
	}

	public void setConductedtestsoftoday(int conductedtestsoftoday) {
		this.conductedtestsoftoday = conductedtestsoftoday;
	}

	public int getTotalconductedtests() {
		return totalconductedtests;
	}

	public void setTotalconductedtests(int totalconductedtests) {
		this.totalconductedtests = totalconductedtests;
	}

	public int getRecoveriesoftoday() {
		return recoveriesoftoday;
	}

	public void setRecoveriesoftoday(int recoveriesoftoday) {
		this.recoveriesoftoday = recoveriesoftoday;
	}

	public int getTotalrecoveries() {
		return totalrecoveries;
	}

	public void setTotalrecoveries(int totalrecoveries) {
		this.totalrecoveries = totalrecoveries;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
