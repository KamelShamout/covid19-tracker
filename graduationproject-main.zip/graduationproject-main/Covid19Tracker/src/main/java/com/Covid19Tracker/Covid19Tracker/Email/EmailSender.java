package com.Covid19Tracker.Covid19Tracker.Email;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.Covid19Tracker.Covid19Tracker.Entities.Cases;
import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;
import com.Covid19Tracker.Covid19Tracker.Services.CitiesService;
import com.Covid19Tracker.Covid19Tracker.Services.JordanService;
import com.Covid19Tracker.Covid19Tracker.Services.UserService;

@Service
public class EmailSender {
	@Autowired
	private JavaMailSender javamailsender;
	@Autowired
	private CitiesService service;
	@Autowired
	private JordanService jorservices;
	@Autowired
	private UserService userService;

	public void SendEmail(String[] list, String body, String topic) {

		if (!userService.AllAdmins().isEmpty()) {
			SimpleMailMessage message = new SimpleMailMessage();
			message.setFrom("covidtrackeroffical@gmail.com");
			message.setTo(list);
			message.setSubject(topic);
			message.setText(body);
			javamailsender.send(message);
		}

	}

	public void SendUpdates() {

		TotalCases jorcases = jorservices.LastUpdate();
		List<Cases> temp = service.LastCitiesUpdateForEmail();
		String message = "the Cases For this date " + service.LastDateForEmail() + "\n";
		for (Cases cases : temp) {
			message += cases.getCountry().getName() + " and the number of cases is " + cases.getNumberofcases() + "\n";
		}

		message += "And the cases for Jordan in total \n";
		message += "The cases  is for today " + jorcases.getCasesoftoday() + "\n";
		message += "The total cases  is " + jorcases.getTotalcases() + "\n";
		message += "The  death for today is " + jorcases.getDeathsoftoday() + "\n";
		message += "The total death  is " + jorcases.getTotaldeaths() + "\n";
		message += "The conducted tests for today is " + jorcases.getConductedtestsoftoday() + "\n";
		message += "The total conducted tests is " + jorcases.getTotalconductedtests() + "\n";
		message += "The recoveries for today " + jorcases.getRecoveriesoftoday() + "\n";
		message += "The total recoveries is " + jorcases.getTotalrecoveries() + "\n";

		SendEmail(userService.ReturnAllEmails(), message, "the last update foe covid-19");

	}

}
