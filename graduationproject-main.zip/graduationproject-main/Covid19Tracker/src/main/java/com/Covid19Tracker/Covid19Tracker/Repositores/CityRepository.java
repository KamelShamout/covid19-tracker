package com.Covid19Tracker.Covid19Tracker.Repositores;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Covid19Tracker.Covid19Tracker.Entities.City;

public interface CityRepository extends JpaRepository<City, String> {

}
