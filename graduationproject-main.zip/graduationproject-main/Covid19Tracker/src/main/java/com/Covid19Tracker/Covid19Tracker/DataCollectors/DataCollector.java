package com.Covid19Tracker.Covid19Tracker.DataCollectors;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.Covid19Tracker.Covid19Tracker.Email.EmailSender;
import com.Covid19Tracker.Covid19Tracker.Entities.TotalCases;
import com.Covid19Tracker.Covid19Tracker.Repositores.UrlsRepository;
import com.Covid19Tracker.Covid19Tracker.Services.CitiesService;
import com.Covid19Tracker.Covid19Tracker.Services.JordanService;
import com.Covid19Tracker.Covid19Tracker.Services.UserService;

@Service
@EnableScheduling
public class DataCollector {
	private WebDriver driver;
	private final String url = "https://corona.moh.gov.jo/en/MediaCenter?page=";
	@Autowired
	private UrlsRepository urlsRepository;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private UserService userservice;
	@Autowired
	private CitiesService citiesservices;
	@Autowired
	private JordanService jordanService;
	private String date;
	private FirefoxOptions options ;
	private		int count = 6;


	public DataCollector() {
		options= new FirefoxOptions();
		options.setHeadless(true);
	}
	@Scheduled(fixedRate = 60000*60*5)
	@PostConstruct
	public void GetData() {

		try {
			driver = new FirefoxDriver(options);
			while (count > 0) {
				driver.get(url + count);

				// get the main element that contain all links
				List<WebElement> alldata = driver.findElements(By.linkText("COVID-19 Updates in Jordan"));

				List<Urls> urls = NewUrls(alldata);
				if (!urls.isEmpty()) {

					urlsRepository.saveAll(urls);
					for (Urls urls3 : urls) {
						driver.get(urls3.getUrl());
						if (GetElement(driver) == null) {
							emailSender.SendEmail(userservice.ReturnAdminsEmails(),
									"please check all the cases for this date", date);
							continue;

						}
						SaveCase(GetElement(driver));
						SaveTotalCases(GetElement(driver));
						if (!userservice.AllUsers().isEmpty())
							emailSender.SendUpdates();

					}
				}
				count--;
			}
			count=1;
			driver.quit();
		} catch (Exception e) {
			emailSender.SendEmail(userservice.ReturnAdminsEmails(), "please check all cases for this date" + date,
					"uneable to insert data ");
		}
	}

	public int spliter(String string) {

		int finall = 0;

		String temp = string.replace(",", "");

		String temp2 = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")"));
		finall = Integer.parseInt(temp2);

		return finall;
	}

	public void SaveTotalCases(WebElement element) {
		try {
			TotalCases totalcases = new TotalCases();

			String[] alldata = element.getText().split("\n");
			date = driver.findElement(By.className("timedate")).getText();

			String format = "dd MMMM yyyy";
			Date date2 = null;

			date2 = new SimpleDateFormat(format).parse(date.split(",")[1].trim());

			totalcases.setDate(new Timestamp(date2.getTime()).toString());

			for (int i = 0; i < alldata.length; i++) {
				if (alldata[i].contains("A total of")) {
					totalcases.setCasesoftoday(spliter(alldata[i]));

				}
				if (alldata[i].contains("rise")) {
					totalcases.setTotalcases(spliter(alldata[i]));

				}
				if (alldata[i].contains("deaths")) {
					String[] temp = alldata[i].split(",");
					totalcases.setDeathsoftoday(spliter(temp[0]));

					totalcases.setTotaldeaths(spliter(temp[1]));

				}
				if (alldata[i].contains("conducted")) {
					totalcases.setConductedtestsoftoday(spliter(alldata[i]));
					totalcases.setTotalconductedtests(spliter(alldata[i + 1]));

				}
				if (alldata[i].contains("home isolation")) {
					totalcases.setRecoveriesoftoday(spliter(alldata[i]));

					totalcases.setTotalrecoveries(spliter(alldata[i + 1]));

				}

			}
			if(jordanService.LastUpdate().getDate()!=totalcases.getDate())

			jordanService.CreateCase(totalcases);
			System.out.println("------------SavecaseforJOR--------------------");

		} catch (Exception e) {

			emailSender.SendEmail(userservice.ReturnAdminsEmails(), "please check Jordan cases for this date" + date,
					"uneable to insert data ");
		}

	}

	public WebElement GetElement(WebDriver driver) {
		WebElement temp = null;
		date = driver.findElement(By.className("timedate")).getText();

		List<WebElement> alldata = driver.findElements(By.tagName("html"));
		for (int i = 0; i < alldata.size(); i++) {

			if (!alldata.get(i).getText().contains("distributed")) {

				alldata.remove(alldata.get(i));

				i--;
			}

		}
		if (alldata.isEmpty())
			return null;
		temp = alldata.get(0);

		return temp;

	}

	public void SaveCase(WebElement element) {
		try {
			String[] alldata = element.getText().split("\n");
			date = driver.findElement(By.className("timedate")).getText();

			String format = "dd MMMM yyyy";
			Date date2 = null;

			date2 = new SimpleDateFormat(format).parse(date.split(",")[1].trim());

			date = (new Timestamp(date2.getTime())).toString();

			for (int i = 0; i < alldata.length; i++) {
				String[] temp = new String[2];
				alldata[i] = alldata[i].replace(" ", "");
				if (alldata[i].contains("Casesin")) {
					temp = alldata[i].split("Casesin");
					temp[1] = temp[1].substring(0,
							(temp[1].contains("Amman")) ? temp[1].indexOf(".") : temp[1].indexOf("G"));
					int number = Integer.parseInt(temp[0].replace("(", "").replace(")", ""));
					if(date!=citiesservices.LastDateForEmail())
					citiesservices.InsertDataByCity(temp[1], citiesservices.CreateCase(date, number, temp[1]));

					System.out.println("------------Savecase--------------------");

				}

			}
			if(alldata.length<12)
				emailSender.SendEmail(userservice.ReturnAdminsEmails(), "please check the cases for this date" + date,
						"some of the cities are missing ");
		} catch (Exception e) {

			emailSender.SendEmail(userservice.ReturnAdminsEmails(), "please check the cases for this date" + date,
					"uneable to insert data ");
		}

	}

	public List<Urls> NewUrls(List<WebElement> element) {
		List<Urls> newurls = new ArrayList<Urls>();
		try {

			for (WebElement webElement : element) {
				long id = Long.parseLong(
						webElement.getAttribute("href").replace("https://corona.moh.gov.jo/en/MediaCenter/", ""));
				if (urlsRepository.existsById(id))
					continue;
				newurls.add(new Urls(webElement.getAttribute("href"), id));
			}
		} catch (Exception e) {

		}
		if (!newurls.isEmpty())
			Collections.sort(newurls);
		return newurls;
	}

}
