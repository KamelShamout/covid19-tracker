package com.Covid19Tracker.Covid19Tracker.DataCollectors;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Urls")
public class Urls implements Comparable<Urls> {

	private String url;
	@Id
	private long id;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Urls() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Urls(String url, long id) {
		super();
		this.url = url;
		this.id = id;
	}

	@Override
	public String toString() {
		return "Urls [url=" + url + ", id=" + id + "]";
	}

	@Override
	public int compareTo(Urls o) {
		// TODO Auto-generated method stub
		return (int) (getId() - o.getId());
	}
}
