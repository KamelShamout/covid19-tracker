package com.Covid19Tracker.Covid19Tracker.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Covid19Tracker.Covid19Tracker.Entities.User;
import com.Covid19Tracker.Covid19Tracker.Repositores.UserRepository;

@Service
public class UserService {
	@Autowired
	public UserRepository userRepository;

	public String[] ReturnAdminsEmails() {

		return userRepository.findAdminsEmails();
	}

	public String[] ReturnAllEmails() {

		return userRepository.findAllEmails();
	}

	public User findbyEmail(String email) {

		User user = userRepository.findByEmail(email.trim());
		return user;
	}

	public boolean Signup(User user) {
		if (userRepository.findByEmail(user.getEmail()) != null)
			return false;
		CreateUser(user);
		return true;

	}

	public int Login(Login login) {
		User user = userRepository.findByEmail(login.getEmail());
		if (user == null)
			return -1;
		int x = login.getPassword().compareTo(user.getPassword());
		if (x == 0)
			return 0;
		else
			return 1;
	}

	public boolean UpdateInfo(User user) {
		if (userRepository.findByEmail(user.getEmail()) == null)
			return false;
		User temp = userRepository.findByEmail(user.getEmail());
		temp.setCity(user.getCity());
		temp.setName(user.getName());
		temp.setPassword(user.getPassword());
		userRepository.save(temp);

		return true;
	}

	public boolean CreateUser(User user) {
		user.setId(userRepository.findAll().isEmpty() ? 0 : userRepository.findtheLastId() + 1);
		userRepository.saveAndFlush(user);
		return true;
	}

	public List<User> AllUsers() {
		return userRepository.findAll();
	}

	public List<User> AllAdmins() {
		return userRepository.findByType(true);
	}

}
