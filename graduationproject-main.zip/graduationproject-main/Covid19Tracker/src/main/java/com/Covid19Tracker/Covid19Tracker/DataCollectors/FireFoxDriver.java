package com.Covid19Tracker.Covid19Tracker.DataCollectors;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Configuration;

@Configuration
public class FireFoxDriver {
	@PostConstruct
	public void ChromeDriverpath() {
		System.setProperty("webdriver.firefox.driver", "/Covid19Tracker/geckodriver.exe");

	}

}
