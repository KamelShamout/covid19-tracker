create table covid19.Cases (
       id bigint not null,
        date varchar(255),
        numberofcases integer not null,
        city_id varchar(64) not null,
        primary key (id)
    );
create table covid19.Cities (
       city_id varchar(64) not null,
        name varchar(255),
        primary key (city_id)
    );
    create table covid19.Jordan_Case (
       id bigint not null,
        casesoftoday integer not null,
        conductedtestsoftoday integer not null,
        date varchar(255),
        deathsoftoday integer not null,
        recoveriesoftoday integer not null,
        totalcases integer not null,
        totalconductedtests integer not null,
        totaldeaths integer not null,
        totalrecoveries integer not null,
        primary key (id)
    );
 create table covid19.Urls (
       id bigint not null,
        url varchar(255),
        primary key (id)
    );
create table covid19.User (
       id bigint not null,
        city varchar(255),
        email varchar(64),
        isadmin bit not null,
        name varchar(255),
        password varchar(255),
        primary key (id)
    );  
    
INSERT INTO `covid19`.`user` (`id`, `city`, `email`, `isadmin`, `name`, `password`)
 VALUES (0,"Irbid", "belalkamel113@gmail.com",  true,  "Kamel","123456789");
INSERT INTO `covid19`.`user` (`id`, `city`, `email`, `isadmin`, `name`, `password`)
 VALUES (1,"Irbid", "Emqasem17@cit.just.edu.jo",  true,"Eyad", "123456789");
INSERT INTO `covid19`.`user` (`id`, `city`, `email`, `isadmin`, `name`, `password`) 
VALUES (2, "Irbid","moyed.tayem99@gmail.com",  true, "moyed","123456789");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Amman", "Amman");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Al-zarqaa", "Al-zarqaa");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Al-Balqaa", "Al-Balqaa");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Madaba", "Madaba");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Aqaba", "Aqaba");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Ajloun", "Ajloun");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Irbid", "Irbid");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Jerash", "Jerash");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Al-Karak" ,"Al-Karak");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("AlTafilah", "AlTafilah");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Al-Mafraq", "Al-Mafraq");
INSERT INTO `covid19`.`cities` (`city_id`, `name`) VALUES ("Ma'an", "Ma'an");