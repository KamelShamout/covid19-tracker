import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ChartModel } from 'src/app/interfaces/ChartModel';
import { IsLoggedService } from 'src/app/Login/is-logged.service';
import { CasesByCityService } from 'src/app/services/cases-by-city.service';

@Component({
  selector: 'city-chart',
  templateUrl: './city-chart.component.html',
  styleUrls: ['./city-chart.component.css']
})
export class CityChartComponent {
  constructor(private caseByCityService: CasesByCityService, private isLogged: IsLoggedService) { }

  numberOfCase = 14
  datePipe:DatePipe = new DatePipe('en-US');

  chartData$: Observable<ChartModel> = this.caseByCityService.getbycountry(
    this.isLogged.getLogin()? this.isLogged.getCurrentUser().city:'Irbid')
    .pipe(
      map(data => {
        let newdate = data.cases.slice(data.cases.length - this.numberOfCase, data.cases.length)
        let temp: ChartModel = {
          labels: newdate.map(city => this.datePipe.transform(city.date.toString(),'mediumDate')),
          datasets: []
        }; 

        temp.datasets.push({
          data:newdate.map(city => city.numberofcases), label: `${ this.isLogged.getLogin()? this.isLogged.getCurrentUser().city:"Irbid"} Cases`,
          borderColor: '#42A5F5', fill: false, lineTension: 0
        })

        return temp;
      })
    );

    Slice(){
      this.chartData$ = this.caseByCityService.getbycountry(
        this.isLogged.getLogin()? this.isLogged.getCurrentUser().city:'Irbid')
        .pipe(
          map(data => {
            let newdate = data.cases.slice(data.cases.length - this.numberOfCase, data.cases.length)
            let temp: ChartModel = {
              labels: newdate.map(city => this.datePipe.transform(city.date.toString(),'mediumDate')),
              datasets: []
            }; 
    
            temp.datasets.push({
              data:newdate.map(city => city.numberofcases), label: `${ this.isLogged.getLogin()? this.isLogged.getCurrentUser().city:"Irbid"} Cases`,
              borderColor: '#42A5F5', fill: false, lineTension: 0
            })
    
            return temp;
          })
        );
    }
}




