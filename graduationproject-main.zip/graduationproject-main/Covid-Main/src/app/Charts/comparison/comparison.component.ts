import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ChartModel } from 'src/app/interfaces/ChartModel';
import { ICity } from 'src/app/interfaces/City';
import { cases } from 'src/app/interfaces/cityCases';
import { GetAllCasesService } from 'src/app/services/get-all-cases.service';

@Component({
  selector: 'app-comparison',
  templateUrl: './comparison.component.html',
  styleUrls: ['./comparison.component.css']
})
export class ComparisonComponent  {
  datePipe:DatePipe = new DatePipe('en-US');
  city1 = "Irbid"
  city2 = "Amman"
  days = 14
  cities
  tableData$:Observable<cases[][]>=this.AllCases.getAllCases(this.city1,this.city2).pipe(
    map(data=>{
      let temp:cases[][]=[]
      data.map(cities=>{
        if(this.city1==cities.name){
            temp[0]=cities.cases
        }
        if(this.city2==cities.name){
          temp[1]=cities.cases
      }
      })
      return temp;
    })
  )
  chartData$: Observable<ChartModel> = this.AllCases.getAllCases(this.city1, this.city2).pipe(
    map(data => {
      let City1:cases[]
      let City2:cases[]
      data.map(cities => {
        if (this.city1 == cities.name) {
           City1 = cities.cases.slice(cities.cases.length-this.days,cities.cases.length);
           console.log(cities)
        }
        if (this.city2 == cities.name){
          City2 = cities.cases.slice(cities.cases.length-this.days,cities.cases.length);
        }
        
      })
     
      let temp: ChartModel = {
        labels: City1.map(city=> this.datePipe.transform(city.date.toString(),'mediumDate')),
        datasets: []
      }
       temp.datasets.push({
       data: City1.map(city => city.numberofcases), label: `Number Of Cases For ${this.city1}`,
       borderColor: '#42A5F5', fill: false, lineTension: 0,backgroundColor: '#FFA726'
     })
       temp.datasets.push({
      data: City2.map(city => city.numberofcases), label: `Number Of Cases For ${this.city2}`,
        borderColor: '#FFA726', fill: false, lineTension: 0, backgroundColor: '#42A5F5'
       })
      return temp;
    })
  )
  constructor(private AllCases: GetAllCasesService) { }

  changCity(){
    console.log("city Changed")
    this.chartData$=this.AllCases.getAllCases(this.city1, this.city2).pipe(
      map(data => {
        let City1:cases[]
        let City2:cases[]
        data.map(cities => {
          if (this.city1 == cities.name) {
             City1 = cities.cases.slice(cities.cases.length-this.days,cities.cases.length);
             console.log(cities)
          }
          if (this.city2 == cities.name){
            City2 = cities.cases.slice(cities.cases.length-this.days,cities.cases.length);
          }
          
        })
       
        let temp: ChartModel = {
          labels: City1.map(city=> this.datePipe.transform(city.date.toString(),'mediumDate')),
          datasets: []
        }
         temp.datasets.push({
         data: City1.map(city => city.numberofcases), label: `Number Of Cases For ${this.city1}`,
         borderColor: '#42A5F5', fill: false, lineTension: 0, backgroundColor: '#FFA726'
       })
         temp.datasets.push({
        data: City2.map(city => city.numberofcases), label: `Number Of Cases For ${this.city2}`,
          borderColor: '#FFA726', fill: false, lineTension: 0, backgroundColor: '#42A5F5'
         })
        return temp;
      })
    )
    this.tableData$=this.AllCases.getAllCases(this.city1,this.city2).pipe(
      map(data=>{
        let temp:cases[][]=[]
        data.map(cities=>{
          if(this.city1==cities.name){
              temp[0]=cities.cases
          }
          if(this.city2==cities.name){
            temp[1]=cities.cases
        }
        })
        return temp;
      })
    )
  }
  Slice(){
   
    
    this.chartData$ = this.AllCases.getAllCases(this.city1, this.city2).pipe(
      map(data => {
        let City1:cases[]
        let City2:cases[]
        data.map(cities => {
          if (this.city1 == cities.name) {
             City1 = cities.cases.slice(cities.cases.length-this.days,cities.cases.length);
          }
          if (this.city2==cities.name){
            City2 = cities.cases.slice(cities.cases.length-this.days,cities.cases.length);
          }
          
        })
       
        let temp: ChartModel = {
          labels: City1.map(city=>this.datePipe.transform(city.date.toString(),'mediumDate')),
          datasets: []
        }
         temp.datasets.push({
         data: City1.map(city => city.numberofcases), label: `Number Of Cases For ${this.city1}`,
          backgroundColor: '#FFA726',borderColor: '#42A5F5', fill: false, lineTension: 0,
       })
         temp.datasets.push({
        data: City2.map(city => city.numberofcases), label: `Number Of Cases For ${this.city2}`,
        backgroundColor: '#42A5F5',borderColor: '#FFA726', fill: false, lineTension: 0
         })
        return temp;
      })
    )

  }

}
