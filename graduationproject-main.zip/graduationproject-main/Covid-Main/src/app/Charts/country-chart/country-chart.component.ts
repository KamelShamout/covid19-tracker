import { DatePipe } from '@angular/common';
import { templateJitUrl } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { PrimeNGConfig } from 'primeng/api';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ChartModel } from 'src/app/interfaces/ChartModel';
import { ICountryCases } from 'src/app/interfaces/ICountryCases';
import { JordanCasesService } from 'src/app/services/jordan-cases.service';

@Component({
  selector: 'country-chart',
  templateUrl: './country-chart.component.html',
  styleUrls: ['./country-chart.component.css']
})
export class CountryChartComponent  {
  showDeathes=false;
  datePipe:DatePipe = new DatePipe('en-US');
  data: any;
  Options: any;
  numberOfCase = 14
  chartData$: Observable<ChartModel> = this.JordanData.jordanCases().pipe(
    map(data => {
      let newdate = data.slice(data.length - this.numberOfCase, data.length)
      let temp: ChartModel = {
        labels: newdate.map(country => this.datePipe.transform(country.date.toString(),'mediumDate')),
        datasets: []

      };
      temp.datasets.push({
        data: newdate.map(city => city.casesoftoday), label: `Number Of Cases`,
        backgroundColor: '#42A5F5', fill: false, lineTension: 0
      })
      temp.datasets.push({
        data: newdate.map(city => city.recoveriesoftoday), label: `Number Of Recovers`,
        backgroundColor: '#FFA726', fill: false, lineTension: 0
      })
      return temp
    }))

  constructor(private JordanData: JordanCasesService) {

  }

  Slice() {
   if (!this.showDeathes){
    this.showCases();
    }
    else{
      this.showdeaths()
    }

  }
  showdeaths(){
    this.showDeathes=true;
    this.chartData$ = this.JordanData.jordanCases().pipe(
      map(data => {
        let newdate = data.slice(data.length - this.numberOfCase, data.length)
        console.log(newdate)
        let temp: ChartModel = {
          labels: newdate.map(country => this.datePipe.transform(country.date.toString(),'mediumDate')),
          datasets: []

        };
        temp.datasets.push({
          data: newdate.map(city => city.deathsoftoday), label: `Number Of Cases`,
          borderColor: '#42A5F5', fill: false, lineTension: 0,  backgroundColor: '#42A5F5'
        })
        

        return temp
      }))
  }
  showCases(){
    this.showDeathes=false;
    this.chartData$ = this.JordanData.jordanCases().pipe(
      map(data => {
        let newdate = data.slice(data.length - this.numberOfCase, data.length)
        console.log(newdate)
        let temp: ChartModel = {
          labels: newdate.map(country => this.datePipe.transform(country.date.toString(),'mediumDate')),
          datasets: []

        };
        temp.datasets.push({
          data: newdate.map(city => city.casesoftoday), label: `Number Of Cases`,
          borderColor: '#42A5F5', fill: false, lineTension: 0,  backgroundColor: '#42A5F5'
        })
        temp.datasets.push({
          data: newdate.map(city => city.recoveriesoftoday), label: `Number Of Recovers`,
          borderColor: '#FFA726', fill: false, lineTension: 0, backgroundColor: '#FFA726'
        })

        console.log(temp)
        return temp
      }))
  }
  
  
  
  



}