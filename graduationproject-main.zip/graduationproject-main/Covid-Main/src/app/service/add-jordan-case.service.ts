import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ICountryCases } from '../interfaces/ICountryCases';

@Injectable({
  providedIn: 'root'
})
export class AddJordanCaseService {
  url="server/jordancases/insertcase";
  constructor(private https:HttpClient) { }

  addJordanNewCase(jordanCase:ICountryCases):Observable<boolean>{
    return this.https.post<boolean>(this.url,jordanCase);
  }
}
