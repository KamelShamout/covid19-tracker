import { TestBed } from '@angular/core/testing';

import { AddJordanCaseService } from './add-jordan-case.service';

describe('AddJordanCaseService', () => {
  let service: AddJordanCaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddJordanCaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
