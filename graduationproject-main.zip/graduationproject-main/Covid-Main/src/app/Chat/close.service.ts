import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CloseService {
flag=false;
  constructor() { }
  get isClosed(){
    return this.flag;
  }
  close(){
    this.flag=!this.flag;
  }
}


