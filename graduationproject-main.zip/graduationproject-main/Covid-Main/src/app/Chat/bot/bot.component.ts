import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CasesByCityService } from 'src/app/services/cases-by-city.service';
import { CityLastUpdateService } from 'src/app/services/city-last-update.service';
import { CloseService } from '../close.service';
import { ICity } from 'src/app/interfaces/City';
import { JordanLastCaseService } from 'src/app/services/jordan-last-case.service';





@Component({
  selector: 'app-bot',
  templateUrl: './bot.component.html',
  styleUrls: ['./bot.component.css']
})
export class BotComponent {

  @ViewChild("chat") chat:ElementRef;

  answers = ["hello Im covid 19 chat bot how can I help you?"];
  mess = " ";
  constructor(private closeService:CloseService,private CityAllCases:CasesByCityService,private JoLastCase: JordanLastCaseService) { }

  
   
  

  get isClosed(){
    return this.closeService.isClosed;
  }
  close(){
    this.closeService.close();
    console.log(this.closeService.isClosed);
   
  }
  addmore() {
    this.answers.push(this.mess);
    this.mess=this.mess.toLowerCase();


  
     if (this.mess.indexOf("covid")!== -1 ||this.mess.indexOf("covid19")!== -1 ||
     this.mess.indexOf("covid-19")!== -1){
       if (this.mess.indexOf("symptoms")!==-1 ||this.mess.indexOf("Symptoms")!==-1){
        this.answers.push("Most common symptoms:\nfever\ndry cough\ntiredness\nLess common symptoms:\naches and pains\nsore throat\ndiarrhoea\nconjunctivitis\nheadache\nloss of taste or smell\na rash on skin, or discolouration of fingers or toes")
       }
       else if (this.mess.indexOf("prevention")!==-1 ||this.mess.indexOf("Prevention")!==-1||this.mess.indexOf("preventing")!==-1 ||this.mess.indexOf("Preventing")!==-1){
        this.answers.push(`To prevent the spread of COVID-19:\nClean your hands often. Use soap and water, or an alcohol-based hand rub.\n
        Maintain a safe distance from anyone who is coughing or sneezing.\n
        Wear a mask when physical distancing is not possible.\n
        Don’t touch your eyes, nose or mouth.\n
        Cover your nose and mouth with your bent elbow or a tissue when you cough or sneeze.\n
        Stay home if you feel unwell.\n
        If you have a fever, cough and difficulty breathing, seek medical attention\n`)
           }
           else if (this.mess.indexOf("treatment")!==-1 ||this.mess.indexOf("Treatment")!==-1||this.mess.indexOf("curing")!==-1 ||this.mess.indexOf("Curing")!==-1||this.mess.indexOf("Treating")!==-1 ||this.mess.indexOf("treating")!==-1||this.mess.indexOf("Treate")!==-1 ||this.mess.indexOf("treate")!==-1){
            this.answers.push(`After exposure to someone who has COVID-19, do the following:
            Call your health care provider or COVID-19 hotline to find out where and when to get a test.\n
            Cooperate with contact-tracing procedures to stop the spread of the virus.\n
            If testing is not available, stay home and away from others for 14 days.\n
            While you are in quarantine, do not go to work, to school or to public places. Ask someone to bring you supplies.\n
            Keep at least a 1-metre distance from others, even from your family members.\n
            Wear a medical mask to protect others, including if/when you need to seek medical care.\n
            Clean your hands frequently.\n
            Stay in a separate room from other family members, and if not possible, wear a medical mask.\n
            Keep the room well-ventilated.\n
            If you share a room, place beds at least 1 metre apart.\n
            Monitor yourself for any symptoms for 14 days.\n
            Call your health care provider immediately if you have any of these danger signs: difficulty breathing, loss of speech or mobility, confusion or chest pain.\n
            Stay positive by keeping in touch with loved ones by phone or online, and by exercising at home\n`)
           }
       else{
      this.answers.push("The COVID-19 pandemic, also known as the coronavirus pandemic, is an ongoing global pandemic of coronavirus disease 2019 (COVID-19) caused by severe acute respiratory syndrome coronavirus 2 (SARS-CoV-2). ");
       }
     }
     else if(this.mess.indexOf("cases")!==-1||this.mess.indexOf("case")!==-1||this.mess.indexOf("Cases")!==-1
     ||this.mess.indexOf("Case")!==-1){
      if(this.mess.indexOf("Irbid") !==-1||this.mess.indexOf("irbid")!==-1){
        this.citiesLastCase("Irbid");
        
        
      }
      else if (this.mess.indexOf("Amman")!==-1 ||this.mess.indexOf("amman")!==-1 ){
        this.citiesLastCase("Amman");

      }
      else if (this.mess.indexOf("al-Zarqaa")!==-1 ||this.mess.indexOf("Al-Zarqaa")!==-1 ||this.mess.indexOf("Al-zarqaa")!==-1 ||this.mess.indexOf("al-zarqaa")!==-1 ||this.mess.indexOf("zarqaa")!==-1 ||this.mess.indexOf("Zarqaa")!==-1 ){
        this.citiesLastCase("Al-zarqaa");

      }
      else if (this.mess.indexOf("Al-balqaa")!==-1 ||this.mess.indexOf("Al-Balqaa")!==-1 ||this.mess.indexOf("al-balqaa")!==-1 ||this.mess.indexOf("Balqaa")!==-1 ||this.mess.indexOf("Balqaa")!==-1 ){
        this.citiesLastCase("Al-Balqaa");

      }
      else if (this.mess.indexOf("Madaba")!==-1 ||this.mess.indexOf("madaba")!==-1 ){
        this.citiesLastCase("Madaba");

      }
      else if (this.mess.indexOf("Aqaba")!==-1 ||this.mess.indexOf("aqaba")!==-1 ){
        this.citiesLastCase("Aqaba");
      }
      else if (this.mess.indexOf("Ajloun")!==-1 ||this.mess.indexOf("ajloun")!==-1 ){
        this.citiesLastCase("Ajloun");

      }
      else if (this.mess.indexOf("Jerash")!==-1 ||this.mess.indexOf("jerash")!==-1 ){
        this.citiesLastCase("Jerash");

      }
      else if (this.mess.indexOf("Al-karak")!==-1 ||this.mess.indexOf("Al-Karak")!==-1 ||this.mess.indexOf("al-Karak")!==-1||this.mess.indexOf("Karak")!==-1 ||this.mess.indexOf("karak")!==-1 ){
        this.citiesLastCase("Al-Karak");

      }
      else if (this.mess.indexOf("Altafilah")!==-1 ||this.mess.indexOf("AlTafilah")!==-1 ||this.mess.indexOf("alTafilah")!==-1||this.mess.indexOf("Tafilah")!==-1 ||this.mess.indexOf("tafilah")!==-1 ){
        this.citiesLastCase("AlTafilah");

      }
      else if (this.mess.indexOf("Al-Mafraq")!==-1 ||this.mess.indexOf("al-Mafraq")!==-1||this.mess.indexOf("mafraq")!==-1 ||this.mess.indexOf("Mafraq")!==-1 ){
        this.citiesLastCase("Al-Mafraq");

      }
      else if (this.mess.indexOf("Ma'an")!==-1 ||this.mess.indexOf("ma'an")!==-1 ){
        this.citiesLastCase("Ma'an");

      }
      else if (this.mess.indexOf("Jordan")!==-1||this.mess.indexOf("jordan")!==-1){
        this.JoLastCase.LastCase().subscribe(res=>{
          this.answers.push("Jordan total cases for today is :"+res.casesoftoday+"\nTotal recovres : "+res.recoveriesoftoday+"\nTotal deaths : "+res.deathsoftoday);
        })

      }

     }
     else{
      this.answers.push("sorry I dont understand your question");
     }

     this.mess=null;
     
  }
  citiesLastCase(name:string){
    this.CityAllCases.getbycountry(name).subscribe(res=>{
      this.answers.push("Irbid cases for today is : "+res.cases[res.cases.length-1].numberofcases.toString());
    });
  }

}
