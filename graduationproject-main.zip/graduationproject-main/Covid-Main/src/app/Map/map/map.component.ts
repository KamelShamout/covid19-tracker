import { Component, OnInit } from '@angular/core';
import * as mapboxgl from 'mapbox-gl';
import { environment } from 'src/environments/environment';
import {SmapService} from "../smap.service";

@Component({
  selector: 'map-app',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {

  constructor(private mapService:SmapService) {

  }
  


  


  ngOnInit(): void {
   this.mapService.buildMap();
   this.mapService.updatePopup();
    
   
    
  }
  
}
