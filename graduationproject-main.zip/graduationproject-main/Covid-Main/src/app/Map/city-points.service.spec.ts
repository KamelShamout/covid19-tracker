import { TestBed } from '@angular/core/testing';

import { CityPointsService } from './city-points.service';

describe('CityPointsService', () => {
  let service: CityPointsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CityPointsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
