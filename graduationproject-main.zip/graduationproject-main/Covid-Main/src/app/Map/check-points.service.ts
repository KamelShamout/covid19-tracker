import { Injectable } from '@angular/core';
import * as mapboxgl from 'mapbox-gl';
@Injectable({
  providedIn: 'root'
})
export class CheckPointsService {
  data: mapboxgl.AnySourceData = {
    type: "geojson",
    data: {
      "type": "FeatureCollection",
      "features": [{
        "type": "Feature",
        "properties": {
          Text: "<strong>Dahiyyat Al Hussain Medical Center</strong><br> Phone number :7278156 <br>Working Hours:	09:00AM–2:30PM"
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8459686, 32.5245653
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>MedLabs Medical Lab</strong> <br> Phone number :+96227255029 <br> Working Hours: 08:00AM-07:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8781781, 32.5394396
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Ibn Sina Health Center</strong> <br> Phone number :+96227271134 <br> Working Hours: 08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8469014, 32.5547299
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Medical Center Maan</strong> <br> Phone number :+96232132986 <br> Working Hours:Opens 24 Hours'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7082542, 30.190855
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي معان الشامل</strong> <br> Phone number :+96232131706 <br> Working Hours:Opens 24 Hours'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7276335, 30.1971734
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي العبدلية الأولي</strong> <br> Phone number :+96232130253 <br> Working Hours:Opens 24 Hours'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.5227464, 30.4509521
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي الياروت الأولي</strong> <br> Phone number :No Number <br> Working Hours:08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7218633, 31.2974266
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي المرج الأولي</strong> <br> Phone number :No Number <br> Working Hours:08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7258021, 31.1674475
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز مؤته الصحي</strong> <br> Phone number :No Number <br> Working Hours:08:00AM-04:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7258021, 31.1674475
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Comprehensive Health Center</strong> <br> Phone number :No Number <br> Working Hours:08:00AM-04:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7258021, 31.1674475
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي خالد بن الوليد (الزينة) الأولي</strong> <br> Phone number :No Number <br> Working Hours:08:00AM-04:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7258021, 31.1674475
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي البقيع الشامل السلط</strong> <br> Phone number :+96253551423<br> Working Hours:08:30AM-03:30PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7087302, 32.0397629
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Health Center Mahis</strong> <br> Phone number :No Number<br> Working Hours:07:30AM-02:30PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7087302, 32.0397629
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي الهاشمية عجلون</strong> <br> Phone number :No Number<br> Working Hours:Opens 24 Hours'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.6560605, 32.3641925
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي عبين عجلون</strong> <br> Phone number :No Number<br> Working Hours:Opens 24 Hours'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8125255, 32.3581345
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Comprehensive Health Center</strong> <br> Phone number :No Number<br> Working Hours:08:00AM-04:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.62055, 30.8380715
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي العيص / الشامل</strong> <br> Phone number :+96232250490<br> Working Hours:08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.6433562, 30.841483
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي العقبة</strong> <br> Phone number :No Number<br> Working Hours:09:00AM-05:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.0247983, 29.5622552
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Health center Princess Basma</strong> <br> Phone number :No Number<br> Working Hours:08:00AM-02:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.0003788, 29.5570938
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي جبل الامير حمزة</strong> <br> Phone number :+962787214598<br> Working Hours:08:00AM-06:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            36.018799, 32.0307393
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي الامير عبدالله الاولي</strong> <br> Phone number :No Number<br> Working Hours:Opens 24 Hours'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            36.0949004, 32.0731405
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>Health center</strong> <br> Phone number :+96226351098<br> Working Hours:08:00AM-04:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8827831, 32.3072065
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي الرازي</strong> <br> Phone number :No Number<br> Working Hours:08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8373895, 32.2586384
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي مادبا الغربي</strong> <br> Phone number :No Number<br> Working Hours:08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7884021, 31.7162687
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي حنينا</strong> <br> Phone number :No Number<br> Working Hours:09:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.7795268, 31.7320785
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>MedLabs Medical Laboratory</strong> <br> Phone number :+96265921630<br> Working Hours:08:00AM-07:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8255897, 31.9637613
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي مرج الحمام</strong> <br> Phone number :+96265712725<br> Working Hours:08:00AM-03:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.8412153, 31.9023167
          ]
        }
      },
      {
        "type": "Feature",
        "properties": {
          Text: '<strong>مركز صحي الزهور</strong> <br> Phone number :+96264399165<br> Working Hours:09:00AM-02:00PM'
        },
        "geometry": {
          "type": "Point",
          "coordinates": [
            35.9161511, 31.9227138
          ]
        }
      },
      ]
    }
  }

  checkupPoints(): mapboxgl.AnySourceData {
    return this.data;
  }
  constructor() { }
}
