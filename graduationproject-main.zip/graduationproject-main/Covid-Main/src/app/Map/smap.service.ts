import { Injectable, OnInit } from '@angular/core';
import * as mapboxgl from 'mapbox-gl';
import { environment } from 'src/environments/environment';
import { CityLastUpdateService } from '../services/city-last-update.service';
import { CheckPointsService } from './check-points.service';
import { CityPointsService } from './city-points.service';
import { fillData } from "./fillsPoints";


@Injectable({
  providedIn: 'root'
})
export class SmapService implements OnInit {
  map: mapboxgl.Map;
  public citysLastUpdate;

  set cityLastUpdate(data){
    this.citysLastUpdate=data
  }
  get cityLastUpdate(){
    return this.citysLastUpdate
  }

  constructor(private cityPointService: CityPointsService, private CheckUpPointsService: CheckPointsService) {
    Object.getOwnPropertyDescriptor(mapboxgl, "accessToken").set(environment.mapbox.accessToken);
   
    
  }
  ngOnInit(): void {

  }
  

  buildMap() {


    this.map = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/moyedtayem411/ckk0sdxyp1tbf17p8unu9cfrq',
      center: [36.0014904, 31.2773665], zoom: 6.5, minZoom: 6, maxZoom: 12
    });

  }
  updatePopup() {

    var ID = null
    this.map.on("load", () => {
      this.map.addSource('checkuppoints', this.CheckUpPointsService.checkupPoints());
      this.map.addSource('points', this.cityPointService.cityPoints1());
      this.map.addSource("fills", fillData)
      //for fill
      this.map.addLayer({
        id: "fillLayer",
        source: "fills",
        type: "fill", paint: {
          "fill-color": "#61adff",
          "fill-opacity": [
            'case',
            ['boolean', ['feature-state', 'hover'], false],
            .8,
            0.0
          ]

        }
      })

      this.map.on("click", "fillLayer", e => {
        this.map.getCanvas().style.cursor = 'pointer';
        console.log(e.features[0].properties.index)
        //console.log(e.features[0].id)
        if (e.features.length > 0) {
          if (ID !== null) {
            this.map.setFeatureState(
              { source: 'fills', id: ID },
              { hover: false }

            );

          }
          ID = e.features[0].id;
          this.map.setFeatureState(
            { source: 'fills', id: ID },
            { hover: true }
          );
        }
      });


      this.map.on('mouseleave', 'fillLayer', () => {
        this.map.getCanvas().style.cursor = '';
        if (ID !== null) {
          this.map.setFeatureState(
            { source: 'fills', id: ID },
            { hover: false }
          );
        }
        ID = null;
      });

      //for city points 
      this.map.addLayer({
        id: 'pointsLayer',
        source: "points",
        type: 'circle',
        paint: {
          "circle-opacity": .4,
          "circle-radius": 10,
          "circle-color": "red"
        }
      });
      //for check up points 
      this.map.addLayer({
        id: "checkuppointslayer",
        source: "checkuppoints",
        type: "symbol", layout: {
          "icon-image": "hospital-11", "icon-size": 1,

        }
        , maxzoom: 12.1, minzoom: 9.5

      })

    });
    //for city points
    var popup = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false
    });
    this.map.on("mouseenter", "pointsLayer", e => {
      this.map.getCanvas().style.cursor = 'pointer';
      popup.setLngLat(e.lngLat).setHTML("<span>" + e.features[0].properties.Text + "</span> ").addTo(this.map);
    })
    this.map.on("click", "pointsLayer", e => {
      this.map.flyTo({ center: e.lngLat, zoom: 10 });

    })
    this.map.on("mouseleave", "pointsLayer", () => {
      this.map.getCanvas().style.cursor = '';
      popup.remove();
    })
    //for check ups
    var popup2 = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false
    });
    this.map.on("mouseenter", "checkuppointslayer", e => {
      this.map.getCanvas().style.cursor = 'pointer';
      popup2.setLngLat(e.lngLat).setHTML("<p>" + e.features[0].properties.Text + "</p> ").addTo(this.map);
    })
    this.map.on("click", "checkuppointslayer", e => {
      this.map.flyTo({ center: e.lngLat, zoom: 11.5 })
    })
    this.map.on("mouseleave", "checkuppointslayer", () => {
      this.map.getCanvas().style.cursor = '';
      popup2.remove();
    })
    this.map.on("click", e => console.log(e.lngLat))




  }

}

