import { DatePipe } from '@angular/common';
import { Injectable, OnInit } from '@angular/core';
import * as mapboxgl from 'mapbox-gl';
import { Observable } from 'rxjs';
import { map, tap } from "rxjs/operators"
import { cases } from '../interfaces/cityCases';
import { CityLastUpdateService } from '../services/city-last-update.service';
@Injectable({
  providedIn: 'root'
})
export class CityPointsService {
  datePipe:DatePipe = new DatePipe('en-US');

  constructor(private Https: CityLastUpdateService) {

  }
  citiesLastUpdate$: Observable<any[]> = this.Https.LastCase().pipe(
    map(data =>
   
      Object.keys(data).map(key => (
        {
          "countryName": key,
          
          description: `<h4><strong>${key}</strong></h4> <hr /> <span> Number of cases:${data[key].numberofcases}</span> <br> <span>The Date:${this.datePipe.transform(data[key].date,'mediumDate')}  </span>`
        }))
    ),
    tap(cities => {
      this.data = {
        type: "geojson",
        data: {
          type: "FeatureCollection",
          features: [{
            "type": "Feature",
            "properties": {
              index: 0,
              Text: cities.find(temp => temp.countryName == "Irbid").description

            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.83883791474844, 32.48681266483443
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 1,
              Text: cities.find(temp => temp.countryName == "Amman").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                36.20364630515087, 31.656455626289855
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 2,
              Text:cities.find(temp => temp.countryName == "Al-Mafraq").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                36.2183367788505, 32.29842473208028
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 3,
              Text: cities.find(temp => temp.countryName == "Al-Balqaa").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.634269466576484, 31.953472155249813
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 4,
              Text:  cities.find(temp => temp.countryName == "Al-Karak").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.705666542606764, 31.114808452946363
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 5,
              Text: cities.find(temp => temp.countryName == "Madaba").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.69799306328321, 31.532886021569666
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 6,
              Text:  cities.find(temp => temp.countryName == "Jerash").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.90396165401063, 32.26338786232601
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 7,
              Text: cities.find(temp => temp.countryName == "Ajloun").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.74892523996422, 32.30484082952604
              ]
            }
          },

          {
            "type": "Feature",
            "properties": {
              index: 8,
              Text: cities.find(temp => temp.countryName == "AlTafilah").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.59044373203287, 30.795495147168424
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 9,
              Text:  cities.find(temp => temp.countryName == "Aqaba").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.24251353813884, 29.806118990853236
              ]
            }
          },
          {
            "type": "Feature",
            "properties": {
              index: 10,
              Text: cities.find(temp => temp.countryName == "Al-zarqaa").description
            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                36.8148670090325, 31.83053319109129
              ]
            }
          },

          {
            "type": "Feature",
            "properties": {
              index: 11,
              Text: cities.find(temp => temp.countryName == "Ma'an").description

            },
            "geometry": {
              "type": "Point",
              "coordinates": [
                35.73452782207829, 30.170324083427317
              ]
            }
          },
          
          ]
        }
      };
    })
  )


  lastupdate;
  data: mapboxgl.AnySourceData;



  cityPoints1(): mapboxgl.AnySourceData {
    return this.data;
  }

  lastUpdateFun() {
    return this.lastupdate
  }

}
