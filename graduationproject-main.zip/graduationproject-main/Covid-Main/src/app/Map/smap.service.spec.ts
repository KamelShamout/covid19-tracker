import { TestBed } from '@angular/core/testing';

import { SmapService } from './smap.service';

describe('SmapService', () => {
  let service: SmapService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SmapService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
