import { Component, OnInit } from '@angular/core';
import { FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { IUsers } from 'src/app/interfaces/IUsers';
import { UpdateInfoService } from 'src/app/services/update-info.service';
import { IsLoggedService } from '../is-logged.service';
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-update-info',
  templateUrl: './update-info.component.html',
  styleUrls: ['./update-info.component.css']
})

export class UpdateInfoComponent implements OnInit {
  User:IUsers=null
  constructor(private router:Router,private updateInfoService:UpdateInfoService,private isLogged:IsLoggedService,private toastr: ToastrService) { }
  matcher = new MyErrorStateMatcher();
  IsAdded: boolean;
  hide = true;
  updateUpForm = new FormGroup({
    name: new FormControl("", [Validators.required, Validators.minLength(4)]),
    city: new FormControl("", Validators.required),
    password: new FormControl("", [Validators.required, Validators.minLength(8)]),
    isAdmin: new FormControl(0)

  })

  update(){
    if(this.isLogged.getCurrentUser()!=null){
      this.User=this.isLogged.getCurrentUser()
    }
    this.User.city=this.city.value;
    this.User.name=this.name.value;
    this.User.password=this.passValidtion.value
    if(this.User!=null){
    this.updateInfoService.updateUserInfo(this.User).subscribe(
      res=>{
        if (res==true){
          this.toastr.success("Info has been updated!");
          this.router.navigate(['']);
        }
      }
    )
    
  }
  }
  Cancel(){
    this.router.navigate(['']);
  }

  ngOnInit(): void {
  }
  get name() {
    return this.updateUpForm.get("name");
  }
 
  get passValidtion() {
    return this.updateUpForm.get("password");
  }
  get city() {
    return this.updateUpForm.get("city");
  }

}
