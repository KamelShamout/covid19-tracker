import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IsLoggedService } from '../is-logged.service';
import { IUsers } from "../../interfaces/IUsers";

import { ToastrService } from 'ngx-toastr';
import { LoginService } from 'src/app/services/login.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  currentUser: IUsers;
  hide = true;
  login: boolean;
  isValid: number
  constructor(private islogged: IsLoggedService, private router: Router, private toastr: ToastrService, private HttpLog: LoginService) { }
  loginForm = new FormGroup({
    email: new FormControl("", [Validators.required, Validators.email]),
    password: new FormControl("", [Validators.required, Validators.minLength(8)]),

  })
  forgotPassword(){
    this.toastr.warning("please contact the Following Eamil Address: moyed.tayem99@gmail.com","Forgot Password:",{
      positionClass:'toast-top-center'
    });
  }
  getErrorMessage() {
    if (this.loginForm.get("email").hasError('required')) {
      return 'Email is required';
    }

    return this.loginForm.get("email").hasError('email') ? 'Not a valid email' : '';
  }
  getErrorMessagePassword(){
    if (this.loginForm.get("password").hasError('required')) {
      return 'password is required';
    }
    return this.loginForm.get("password").hasError('minlength') ? 'Password is less than 8 Characters' : '';
  }
  createAccount(){
    this.router.navigate(['singup']);
  }

  onSubmit() {
    this.HttpLog.isValid(this.loginForm.value).subscribe(
      data => {
        this.isValid = data;
        if (this.isValid == 0) {
          this.HttpLog.getUser(this.loginForm.get('email').value).subscribe(
            data => {
              this.currentUser = data;
              this.islogged.currentuser(data);
              console.log(this.currentUser);
              this.islogged.login();
              this.router.navigate(['']);
              this.toastr.success("Welcome back " + this.currentUser.name);
              this.toastr.warning("Remember to wear a Mask and Gloves Before you go out Be Safe!!");
            }
          )

        }
        else {
          this.toastr.error("Email or Password is not correct");

        }

      },
      err => console.log(err)
    )

  }
  get emailValidtion() {
    return this.loginForm.get("email");
  }
  get passValidtion() {
    return this.loginForm.get("password");
  }

}
