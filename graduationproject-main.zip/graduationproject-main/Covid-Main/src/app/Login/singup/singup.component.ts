import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { fromEventPattern } from 'rxjs';
import { LoginService } from 'src/app/services/login.service';
import { IsLoggedService } from '../is-logged.service';


export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css']
})
export class SingupComponent  {
  matcher = new MyErrorStateMatcher();
  IsAdded: boolean;
  hide = true;
  signUpForm = new FormGroup({
    name: new FormControl("", [Validators.required, Validators.minLength(4)]),
    email: new FormControl("", [Validators.required, Validators.email]),
    city: new FormControl("", Validators.required),
    password: new FormControl("", [Validators.required, Validators.minLength(8)]),
    isAdmin: new FormControl(0)

  })

  constructor(private isLogged: IsLoggedService, private router: Router, private toastr: ToastrService, private HTTps: LoginService) { }


  onSubmit() {
    this.HTTps.addNewUser(this.signUpForm.value).subscribe(
      data => {
        this.IsAdded = data;
        if (data){
        console.log(this.signUpForm.value)
        this.isLogged.currentuser(this.signUpForm.value);
        var user = this.isLogged.getCurrentUser();
        this.isLogged.login();
        this.router.navigate(['']);
        this.toastr.success("Thank you for Joining us!!!! " + user.name);
        this.toastr.warning("Remember to wear Mask a and Gloves Before you go out Be Safe!!");
      }
      else {
        this.toastr.error("Email already exists try again");

      }
      }, err => {
        this.toastr.error("Email already exists try again");
        console.log(err)
      }
    )
   
}
  hasAccount(){
  this.router.navigate(['Login']);

}
  get name() {
    return this.signUpForm.get("name");
  }
  get emailValidtion() {
    return this.signUpForm.get("email");
  }
  get passValidtion() {
    return this.signUpForm.get("password");
  }
  get city() {
    return this.signUpForm.get("city");
  }

}
