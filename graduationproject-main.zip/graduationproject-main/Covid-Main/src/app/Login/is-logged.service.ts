import { Injectable } from '@angular/core';
import { IUsers } from '../interfaces/IUsers';

@Injectable({
  providedIn: 'root'
})
export class IsLoggedService {
  private isLogged:boolean=false;
  private currentUser:IUsers|null;

  constructor() { }

  login(){
    this.isLogged=!this.isLogged;
  }

  getLogin():boolean{
    return this.isLogged;
  }

  currentuser(crr:IUsers){
    this.currentUser=crr;
  }
  getCurrentUser(){
    return this.currentUser;
  }

}
