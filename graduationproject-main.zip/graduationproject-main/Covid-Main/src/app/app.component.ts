import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { Router } from '@angular/router';
import { IsLoggedService } from "../app/Login/is-logged.service";
import { CloseService } from './Chat/close.service';
import { IUsers } from './interfaces/IUsers';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  title = 'covid19';
  login:boolean;
  currentUser:IUsers
  chat=false;
  constructor (private isLogged:IsLoggedService,private router:Router,private closeService:CloseService){

  }
  updateinfo(){
    this.router.navigate(["/updateinfo"])
  }
  get isClosed(){
    return this.closeService.isClosed;
  }
  close(){
    this.closeService.close();
   
  }
  showChat(){
    this.chat=!this.chat
  }
  navCountry(){
    this.router.navigate(['/CountryAllData']);
  }

  navCity(){
    this.router.navigate(['/CityAllData']);
  }
  someMethod() {
    this.trigger.openMenu();
  }
  ngOnInit(): void {

  }
  navComparison(){
    this.router.navigate(['/Comparison']);
  }
  navNewCase(){
    this.router.navigate(['/insertNewCase']);

  }
  navNews(){
    this.router.navigate(['/news']);
  }
  home(){
    this.router.navigate(['']);
  }
  NavLogin(){
    this.router.navigate(['Login']);
  }
  get isLoggedIn(): boolean {

    this.currentUser=this.isLogged.getCurrentUser();
    return this.isLogged.getLogin();
  }
  logout(){
    this.isLogged.login();
    this.router.navigate(['']);
  }
  get isAdmin(){
    if (this.currentUser!=null)
    return this.currentUser.isadmin
  }
}
