export interface IUsers {
    name: string,
    password: string,
    city: string,
    email: string,
    isadmin: boolean,
    id:number
}