export interface Announcement{
    url: string,
    announcement_title:string,
    announcement_descrpition:string,
    date:Date
}