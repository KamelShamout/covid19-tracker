export interface ChartModel {
    labels: string[];
    datasets: ChartDatasetModel[];
  }
  export interface ChartDatasetModel {
    label: string;
    data: number[];
    borderColor?: string;
    backgroundColor?:String,
    fill: boolean;
    lineTension: number;
  }