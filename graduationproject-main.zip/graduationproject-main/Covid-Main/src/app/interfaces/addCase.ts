
export interface AddCase {
    cases:number,
    date:string,
    city:string
}