
export interface ICountryCases{
    date:string,
    casesoftoday:number,
    conductedtestsoftoday:number,
    deathsoftoday:number,
    recoveriesoftoday:number,
    totalcases:number,
    totalconductedtests:number,
    totaldeaths:number,
    totalrecoveries:number

}