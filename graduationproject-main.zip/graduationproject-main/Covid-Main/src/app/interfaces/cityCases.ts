export interface cases{
    id:number,
    date:string,
    numberofcases:number,
    
}