import { cases } from "./cityCases";

export interface ICity{
    id:string,
    name:string,
    cases:cases[]
}  