import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertMissingDateComponent } from './insert-missing-date.component';

describe('InsertMissingDateComponent', () => {
  let component: InsertMissingDateComponent;
  let fixture: ComponentFixture<InsertMissingDateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InsertMissingDateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertMissingDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
