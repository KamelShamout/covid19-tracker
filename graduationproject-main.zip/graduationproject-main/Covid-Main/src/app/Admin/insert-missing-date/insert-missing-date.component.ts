import { Component, OnInit, Optional } from '@angular/core';
import { FormGroup, FormControl, Validators, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AddNewCaseService } from 'src/app/services/add-new-case.service';
import { AddCase } from '../../interfaces/addCase';
export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-insert-missing-date',
  templateUrl: './insert-missing-date.component.html',
  styleUrls: ['./insert-missing-date.component.css']
})
export class InsertMissingDateComponent implements OnInit {
  addCase: AddCase;
  date;
  flag=true;
  currentCase: AddCase;
  citys:AddCase[]
 
  constructor(private httpAdd: AddNewCaseService, private toastr: ToastrService,private router:Router) { }

  insert = new FormGroup({

    casesIrbid: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesAmman: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    caseszarqaa: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesAqaba: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesMafraq: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesBalqaa: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesKarak: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesAjloun: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesMaan: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesAlTafilah: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesJerash: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    casesMadaba: new FormControl("", [Validators.required, Validators.pattern("^[0-9]*$"),]),
    date: new FormControl("", Validators.required),
  })
  matcher = new MyErrorStateMatcher();
  get casesMafraq() {
    return this.insert.get("casesMafraq");
  }
  get casesMadaba() {
    return this.insert.get("casesMadaba");
  }
  get casesJerash() {
    return this.insert.get("casesJerash");
  }
  get casesAlTafilah() {
    return this.insert.get("casesMaan");
  }
  get casesMaan() {
    return this.insert.get("casesMaan");
  }
  get casesIrbid() {
    return this.insert.get("casesIrbid");
  }
  get casesAmman() {
    return this.insert.get("casesAmman");
  }
  get caseszarqaa() {
    return this.insert.get("caseszarqaa");
  }
  get casesAqaba() {
    return this.insert.get("casesAqaba");
  }
  get casesBalqaa() {
    return this.insert.get("casesBalqaa");
  }
  get casesKarak() {
    return this.insert.get("casesKarak");
  }
  get casesAjloun() {
    return this.insert.get("casesAjloun");
  }

  get date1() {
    return this.insert.get("date");
  }
  ngOnInit(): void {

  }
  onSubmit() {
    this.citys = [
      { city:'Irbid', cases: this.casesIrbid.value, date: (new Date(this.date1.value)).toISOString() },
      { city:'Amman', cases: this.casesAmman.value, date: (new Date(this.date1.value)).toISOString()  },
      { city:"Al-zarqaa", cases: this.caseszarqaa.value, date: (new Date(this.date1.value)).toISOString()  },
      { city:"Aqaba", cases: this.casesAqaba.value, date: (new Date(this.date1.value)).toISOString() },
      { city:"Al-Mafraq", cases: this.casesMafraq.value, date: (new Date(this.date1.value)).toISOString()  },
      { city: "Al-Balqaa", cases: this.casesBalqaa.value, date:(new Date(this.date1.value)).toISOString()  },
      { city:"Al-Karak",cases: this.casesKarak.value,date:(new Date(this.date1.value)).toISOString() },
      { city:"Ajloun",cases: this.casesAjloun.value,date:(new Date(this.date1.value)).toISOString() },
      { city:"Ma'an",cases: this.casesMaan.value,date:(new Date(this.date1.value)).toISOString() },
      { city:"AlTafilah",cases: this.casesAlTafilah.value,date:(new Date(this.date1.value)).toISOString()  },
      { city:"Jerash" ,cases:this.casesJerash.value,date:(new Date(this.date1.value)).toISOString() },
      { city:"Madaba",cases: this.casesMadaba.value,date:(new Date(this.date1.value)).toISOString()}
    ]

  
   

      this.httpAdd.addNewCase(this.citys).subscribe(
        data => {
          if (data) {
            this.toastr.success(`New Case has been Added `)
            this.router.navigate(["/insertJordanNewDate"]); 
          }
          else {
            this.toastr.error(`Could not Add New Case `)
          }
        },
        err => {
          console.log(err);
        }
      )
    
    
    
  }
}

