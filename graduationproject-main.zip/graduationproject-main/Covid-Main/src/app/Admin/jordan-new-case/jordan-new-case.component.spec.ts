import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JordanNewCaseComponent } from './jordan-new-case.component';

describe('JordanNewCaseComponent', () => {
  let component: JordanNewCaseComponent;
  let fixture: ComponentFixture<JordanNewCaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JordanNewCaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JordanNewCaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
