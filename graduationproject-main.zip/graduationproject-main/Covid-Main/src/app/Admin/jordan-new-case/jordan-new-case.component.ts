import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ICountryCases } from 'src/app/interfaces/ICountryCases';
import { AddJordanCaseService } from 'src/app/service/add-jordan-case.service';

export class MyErrorStateMatcher implements ErrorStateMatcher {

  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}
@Component({
  selector: 'app-jordan-new-case',
  templateUrl: './jordan-new-case.component.html',
  styleUrls: ['./jordan-new-case.component.css']
})
export class JordanNewCaseComponent implements OnInit {

  constructor(private httpAdd: AddJordanCaseService, private toastr: ToastrService,private router:Router) { }
  matcher = new MyErrorStateMatcher();
  jordan:ICountryCases;
  ngOnInit(): void {
  }
  jordanInsert=new FormGroup({
    date:new FormControl("",Validators.required),
    casesoftoday:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    conductedtestsoftoday:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    deathsoftoday:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    recoveriesoftoday:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    totalcases:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    totalconductedtests:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    totaldeaths:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required]),
    totalrecoveries:new FormControl("",[Validators.pattern("^[0-9]*$"),Validators.required])
    
  })
  onSubmit(){
   
    this.jordanInsert.controls["date"].setValue((new Date(this.date.value)).toISOString())
    console.log(this.jordanInsert.value)
    this.jordan ={
      casesoftoday:this.casesoftoday.value,
      totalcases:this.totalcases.value,
      recoveriesoftoday:this.recoveriesoftoday.value,
      totalrecoveries:this.recoveriesoftoday.value,
      deathsoftoday:this.deathsoftoday.value,
      totaldeaths:this.totaldeaths.value,
      conductedtestsoftoday:this.conductedtestsoftoday.value,
      totalconductedtests:this.totalconductedtests.value,
      date:(new Date(this.date.value)).toISOString()
    }

    this.httpAdd.addJordanNewCase(this.jordan).subscribe( data => {
      if (data) {
        this.toastr.success(`New Case has been Added `);
        this.router.navigate(["/insertNewCase"]); 
      }
      else {
        this.toastr.error(`Could not Add New Case `)
      }
    },
    err => {
      console.log(err);
    }
  
);


    
  }
  get totalrecoveries(){
    return this.jordanInsert.get("totalrecoveries");
  }

  get totaldeaths(){
    return this.jordanInsert.get("totaldeaths");
  }

  get totalconductedtests(){
    return this.jordanInsert.get("totalconductedtests");
  }


  get totalcases(){
    return this.jordanInsert.get("totalcases");
  }
  get recoveriesoftoday(){
    return this.jordanInsert.get("recoveriesoftoday");
  }

  get deathsoftoday(){
    return this.jordanInsert.get("deathsoftoday");
  }
  get date(){
    return this.jordanInsert.get('date');
  }
  get casesoftoday(){
    return this.jordanInsert.get("casesoftoday");
  }
  get conductedtestsoftoday(){
    return this.jordanInsert.get("conductedtestsoftoday");
  }
}
