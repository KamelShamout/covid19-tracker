import { TestBed } from '@angular/core/testing';

import { JordanCasesService } from './jordan-cases.service';

describe('JordanCasesService', () => {
  let service: JordanCasesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JordanCasesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
