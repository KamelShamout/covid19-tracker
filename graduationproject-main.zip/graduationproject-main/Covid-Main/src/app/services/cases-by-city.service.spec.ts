import { TestBed } from '@angular/core/testing';

import { CasesByCityService } from './cases-by-city.service';

describe('CasesByCityService', () => {
  let service: CasesByCityService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CasesByCityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
