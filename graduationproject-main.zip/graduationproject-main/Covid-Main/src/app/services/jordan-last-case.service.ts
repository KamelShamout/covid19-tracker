import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ICountryCases } from '../interfaces/ICountryCases';
@Injectable({
  providedIn: 'root'
})
export class JordanLastCaseService {
  url = "/server/jordancases/lastupdate";
  constructor(private Http: HttpClient) { }
  LastCase():Observable<ICountryCases> {
    return this.Http.get<ICountryCases>(this.url)
  }
}
