import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ICity } from '../interfaces/City';

@Injectable({
  providedIn: 'root'
})
export class GetAllCasesService {
  url = "server/cities/allcases"
  constructor(private AllCases: HttpClient) { }
  getAllCases(City1: string, City2: string): Observable<ICity[]> {
    return this.AllCases.get<ICity[]>(this.url).pipe(
      map(cities => cities.map(city => (
        {
          ...city,
          cases: city.cases.sort((a, b) => (new Date(a.date)).getTime() - (new Date(b.date)).getTime())
        }
      ))
      ));
  }

}
