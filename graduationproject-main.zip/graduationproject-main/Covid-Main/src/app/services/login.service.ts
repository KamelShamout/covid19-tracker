import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IUsers } from '../interfaces/IUsers';
import { Login } from '../interfaces/Login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  url="server/user/login"
  url2="server/user/signup"
  url3="server/user/userbyemail"
  constructor(private Https:HttpClient) { }

  isValid(currentLog:Login):Observable<number>{
    return this.Https.post<number>(this.url,currentLog)

  }
  addNewUser(newUser:IUsers):Observable<boolean>{
    return this.Https.post<boolean>(this.url2,newUser);
  }

  getUser(email: string):Observable<IUsers>{
  return this.Https.post<IUsers>(this.url3,email)
  }

}
