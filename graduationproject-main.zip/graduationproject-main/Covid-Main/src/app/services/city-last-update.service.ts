import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

import { cases } from '../interfaces/cityCases';

@Injectable({
  providedIn: 'root'
})
export class CityLastUpdateService {
  data:cases;
  constructor(private Http:HttpClient) { }

   LastCase():Observable<any[]>{
    return this.Http.get<any[]>(environment.CityLastUpdate)


  }
}
