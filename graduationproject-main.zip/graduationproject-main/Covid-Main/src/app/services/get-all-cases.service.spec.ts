import { TestBed } from '@angular/core/testing';

import { GetAllCasesService } from './get-all-cases.service';

describe('GetAllCasesService', () => {
  let service: GetAllCasesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetAllCasesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
