import { TestBed } from '@angular/core/testing';

import { AddNewCaseService } from './add-new-case.service';

describe('AddNewCaseService', () => {
  let service: AddNewCaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddNewCaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
