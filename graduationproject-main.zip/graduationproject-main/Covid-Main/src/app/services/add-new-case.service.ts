import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddCase } from '../interfaces/addCase';
import { cases } from '../interfaces/cityCases';

@Injectable({
  providedIn: 'root'
})
export class AddNewCaseService {
  url = "server/cities/insertdata"
  constructor(private Https: HttpClient) { }

  addNewCase(NewCase: AddCase[]): Observable<boolean> {
    return this.Https.post<boolean>(this.url, NewCase);
  }
}
