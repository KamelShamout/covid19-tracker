import { TestBed } from '@angular/core/testing';

import { JordanLastCaseService } from './jordan-last-case.service';

describe('JordanLastCaseService', () => {
  let service: JordanLastCaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JordanLastCaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
