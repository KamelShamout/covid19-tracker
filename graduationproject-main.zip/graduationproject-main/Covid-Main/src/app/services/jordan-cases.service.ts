import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ICountryCases } from '../interfaces/ICountryCases';

@Injectable({
  providedIn: 'root'
})
export class JordanCasesService {
  url="server/jordancases/cases"
  constructor(private https:HttpClient) { }

  jordanCases():Observable<ICountryCases[]>{
    return this.https.get<ICountryCases[]>(this.url).pipe(
     map(data=>data.sort((a, b) => (new Date(a.date)).getTime() - (new Date(b.date)).getTime()))
        
      
    );
  }
}
