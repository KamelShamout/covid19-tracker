import { TestBed } from '@angular/core/testing';

import { CityLastUpdateService } from './city-last-update.service';

describe('CityLastUpdateService', () => {
  let service: CityLastUpdateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CityLastUpdateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
