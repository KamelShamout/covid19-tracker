import { TitleCasePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ICity } from '../interfaces/City';
import { cases } from '../interfaces/cityCases';

@Injectable({
  providedIn: 'root'
})
export class CasesByCityService {
  url="server/cities/casesbycity"
  constructor(private Https:HttpClient) { }

  getbycountry(cityName:string):Observable<ICity>{
    let pipe = new TitleCasePipe();
    return this.Https.post<ICity>(this.url,cityName)
    .pipe(
      map(city => (
        {
          ...city,
          cases: city.cases.sort((a,b) =>(new Date(a.date)).getTime() - (new Date(b.date)).getTime())
        } 
      ))
    )
  }
 
}
const sortByName = (a, b) => {
  const dateA = a.date;
  const dateB = b.date;
  return (dateA < dateB) ? -1 : (dateA > dateB) ? 1 : 0;
}