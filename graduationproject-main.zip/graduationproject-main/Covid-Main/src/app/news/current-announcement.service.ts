import { Injectable } from '@angular/core';
import { Announcement } from '../interfaces/announcement';

@Injectable({
  providedIn: 'root'
})
export class CurrentAnnouncementService {
  _announcements:null|Announcement[]
  constructor() { 
    this._announcements=new Array<Announcement>();
  }

   announcements(){
    return this._announcements;
  }

    addAnnouncement(announcement:Announcement){
    this._announcements.push(announcement);
  }

  
}
