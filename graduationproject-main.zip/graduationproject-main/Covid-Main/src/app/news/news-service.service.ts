import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class NewsServiceService {

  constructor(private http: HttpClient) {

  }
  newsApiUrl = "https://newsapi.org/v2/top-headlines?q=covid-19&pageSize=52&category=health&language=en&apiKey=401edac8f17c47649fadf763d0dd3ca5";
  topHeading(): Observable<any> {
    return this.http.get(this.newsApiUrl);
  }
}
