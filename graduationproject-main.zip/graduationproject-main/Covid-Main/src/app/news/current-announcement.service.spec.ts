import { TestBed } from '@angular/core/testing';

import { CurrentAnnouncementService } from './current-announcement.service';

describe('CurrentAnnouncementService', () => {
  let service: CurrentAnnouncementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CurrentAnnouncementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
