import { Component, OnInit } from '@angular/core';
import {NewsServiceService} from "../news-service.service";
@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {

  constructor(private newsService:NewsServiceService) { }
  data:any=[];
  ngOnInit(): void {
    this.newsService.topHeading().subscribe((res)=>{
      console.log(res);
     
      this.data=res.articles;
      
    })
  }

}
