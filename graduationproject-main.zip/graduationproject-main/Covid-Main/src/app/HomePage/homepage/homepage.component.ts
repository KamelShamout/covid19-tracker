import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ICountryCases } from 'src/app/interfaces/ICountryCases';
import { CityPointsService } from 'src/app/Map/city-points.service';
import { CityLastUpdateService } from 'src/app/services/city-last-update.service';
import { JordanLastCaseService } from 'src/app/services/jordan-last-case.service';

@Component({
  selector: 'app-guest-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  
  JoCaseToday$:Observable<ICountryCases>=this.JoLastCase.LastCase();
  constructor(private lastCases: CityLastUpdateService,
     private JoLastCase: JordanLastCaseService,
     private x: CityPointsService) { }
  ngOnInit(): void {
    this.x.citiesLastUpdate$.subscribe();
  }

  

}
