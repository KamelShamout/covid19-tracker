import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InsertMissingDateComponent } from './Admin/insert-missing-date/insert-missing-date.component';
import { JordanNewCaseComponent } from './Admin/jordan-new-case/jordan-new-case.component';
import { CityComponent } from './AllCases/city/city.component';
import { CountryComponent } from './AllCases/country/country.component';
import { ComparisonComponent } from './Charts/comparison/comparison.component';
import { HomepageComponent } from './HomePage/homepage/homepage.component';
import { LoginComponent } from './Login/login/login.component';
import { SingupComponent } from './Login/singup/singup.component';
import { UpdateInfoComponent } from './Login/update-info/update-info.component';
import { MapComponent } from './Map/map/map.component';

import { NewsComponent } from './news/news/news.component';


const routes: Routes = [
  { path: '', component: HomepageComponent },
  { path: "insertNewCase", component: InsertMissingDateComponent },
  { path: 'Login', component: LoginComponent },
  { path: "singup", component: SingupComponent },
  { path: "map", component: MapComponent },
  { path: "news", component: NewsComponent }, 
  {path: "CountryAllData", component: CountryComponent},
  {path:"CityAllData",component:CityComponent},{
    path:"Comparison",component:ComparisonComponent
  },{path:"insertJordanNewDate",component:JordanNewCaseComponent},{path:"updateinfo",component:UpdateInfoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
