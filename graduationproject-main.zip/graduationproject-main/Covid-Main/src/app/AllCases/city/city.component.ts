import { Component,PipeTransform  } from '@angular/core';
import { Transform } from 'node:stream';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ICity } from 'src/app/interfaces/City';
import { cases } from 'src/app/interfaces/cityCases';
import { CasesByCityService } from 'src/app/services/cases-by-city.service';

@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.css']
})
export class CityComponent  {
  CityName="Irbid"
  AllData$:Observable<ICity>=this.CityAllCases.getbycountry(this.CityName).pipe(
    map(data=>{
      console.log(data.cases)
      
      return data
    })
  )


  constructor(private CityAllCases:CasesByCityService) { }
 

  changCity(){
    this.AllData$=this.CityAllCases.getbycountry(this.CityName).pipe(
      map(data=>{
        console.log(data.cases)
        return data
      })
    )
  }

}
