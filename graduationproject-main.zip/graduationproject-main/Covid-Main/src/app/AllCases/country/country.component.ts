import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { JordanCasesService } from 'src/app/services/jordan-cases.service';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent {
  CountryData$=this.CountryAllCases.jordanCases();
  constructor(private CountryAllCases:JordanCasesService) { }


}
