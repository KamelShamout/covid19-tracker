import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './HomePage/homepage/homepage.component';
import { LoginComponent } from './Login/login/login.component';
import { SingupComponent } from './Login/singup/singup.component';
import { MapComponent } from './Map/map/map.component';
import { NewsComponent } from './news/news/news.component';
import { HttpClientModule } from "@angular/common/http";
import { NewsServiceService } from "../app/news/news-service.service";
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ToastrModule } from 'ngx-toastr';
import { CountryChartComponent } from './Charts/country-chart/country-chart.component';
import { ChartModule } from 'primeng/chart';
import { CityChartComponent } from './Charts/city-chart/city-chart.component';
import { CityPointsService } from './Map/city-points.service';
import { InsertMissingDateComponent } from './Admin/insert-missing-date/insert-missing-date.component';
import { CountryComponent } from './AllCases/country/country.component';
import { CityComponent } from './AllCases/city/city.component';
import { ComparisonComponent } from './Charts/comparison/comparison.component';
import {MatInputModule} from '@angular/material/input';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule, MAT_DATE_LOCALE } from '@angular/material/core';
import {MatSelectModule} from '@angular/material/select';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatMenuModule} from '@angular/material/menu';
import { JordanNewCaseComponent } from './Admin/jordan-new-case/jordan-new-case.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import { BotComponent } from './Chat/bot/bot.component';
import {MatListModule} from '@angular/material/list';
import { UpdateInfoComponent } from './Login/update-info/update-info.component';








@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    LoginComponent,
    SingupComponent,
    MapComponent,
    NewsComponent,
    CountryChartComponent,
    CityChartComponent,
    InsertMissingDateComponent,
    CountryComponent,
    CityComponent,
    ComparisonComponent,
    JordanNewCaseComponent,
    BotComponent,
    UpdateInfoComponent,
  ],
  imports: [MatMenuModule,ChartModule,MatSidenavModule,MatListModule,
    MatToolbarModule, BrowserModule, BrowserAnimationsModule,MatInputModule,MatDatepickerModule,MatNativeDateModule,MatSelectModule,MatCardModule,MatIconModule,
    AppRoutingModule, HttpClientModule, ReactiveFormsModule, FormsModule, ToastrModule.forRoot(), ChartModule,MatButtonModule,MatGridListModule

  ],
  providers: [NewsServiceService, CityPointsService,{ provide: MAT_DATE_LOCALE, useValue: 'en-GB' }],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule { }
